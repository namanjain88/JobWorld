<?php
$conn=mysqli_connect("localhost","root","","wpfinalproject") or die(mysqli_error($conn));
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$email= mysqli_real_escape_string($conn,$_POST['email']);
$password1= mysqli_real_escape_string($conn,$_POST['password1']);
$password2= mysqli_real_escape_string($conn,$_POST['password2']);

if($password1!=$password2){
    echo '<script>alert("Both Passwords Doesnt Match")</script>';
}
 else {
    

$sql = "UPDATE user SET Password='$password1' where Email='$email'";

if ($conn->query($sql) === TRUE) {
  echo '<script>alert("Password Updated Successfully")</script>';
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
 }
$conn->close();
?>