<html>
    <head>
        <title>JobWorld-EDYoda - Zekelabs Technology</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="amazonWD.css">
        <script language="javascript" src="home.js"></script>
        <link rel="icon" href="favicon.png" type="image/x-icon"/>
        <script>
        function myFunction3() {
  document.getElementById("myDropdown3").classList.toggle("show3");
}

window.onclick = function(event) {
  if (!event.target.matches('.dropbtn3')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show3')) {
        openDropdown.classList.remove('show3');
      }
    }
  }
}</script>
    </head>
    <body>
         <nav id="nav">
        <ul>
            <li><i>JOBWORLD</i></li>
            <li><a href="homepage.php">HOME</a></li>
            <li><button onclick="myFunction()" class="dropbtn">JOBS</button> </li>
                <div id="myDropdown" class="dropdown-content">
                    <a href="alljobs.php">All Jobs</a>
                     <a href="jobsbycity.php">Jobs By City</a>
                     <a href="jobsbydomain.php">Jobs By Domain</a>
                </div>
           
             <li><button onclick="myFunction2()" class="dropbtn2">INTERNSHIPS</button> </li>
            <div id="myDropdown2" class="dropdown-content">
                <a href="allinternships.php">All Internships</a>
                     <a href="internshipbycity.php">Internships By City</a>
                     <a href="internshipbydomain.php">Internships By Domain</a>
                </div>
              
             <li><button onclick="myFunction3()" class="dropbtn3">POST</button></li>     
            <div id="myDropdown3" class="dropdown-content">
                <a href="jobpost.php">Post a Job</a>
                     <a href="PostInternship.php">Post an Internship</a>
                    
                </div>
             <li><a href="resumetemplates.php">RESUME</a></li>
            <li><a href="aboutus.php">ABOUT US</a></li>
            <li style="margin-left: 30%;"><a href="myprofile.php">MY PROFILE</a></li>
        </ul>
        </nav>
        <h1 style="color: blue; font-family: cursive; text-align: center;">Internship at EDYoda - Zekelabs Technology (Sales)</h1>
        <main>
            <img src="edy.png" alt='EDYoda - Zekelabs Technology'>
            <h2>Business Development - Sales<br>EDYoda - Zekelabs Technology</h2>
             <ul>
                    <li>Start Date: 25 November 2021</li>
                    <li>Salary: 12500</li>
                    <li>Duration:3 month</li>
                    <li>Location: Bangalore</li>
            </ul>
            <h2>About EDYoda - Zekelabs Technology:</h2>
            <p>EdYoda - Zekelabs Technology is reimagining higher education. We educate students for on-the-job relevant skills and connect EdYoda graduates to job opportunities through employer partnerships. More than 2,00,000 users are currently learning from the free self-paced courses. Our job-ready programs are for students who need hand-holding and mentorship along the journey. We also promise students assured job opportunities at the end of the program. More than 1400 graduates have completed the instructor-led programs and are working for top companies, including Amazon, Bosch, Cerner, and 200 others.</p>
            <br>
            <h2>Internship Description:</h2>
            <p>Selected interns's day-to-day responsibilities include:</p>
            <ol>
                <li>Analyse our existing customer needs w.r.t. needs, skills, strengths, etc.</li>
                <li>Prepare suggestion for these students based on your research.</li>
                <li>Identify new trends and technologies in the educational field.</li>
                <li>Strategize new ways to attract more students to be part of the community.</li>
            </ol><br>
            <h2>Who can Apply:</h2>
            <ol>
                <li>Pursuing Graduation in B Tech, BBA or any equivalent degree (Any year).</li>
                <li>Are availabvle for a course of 3 month.</li>
                <li>Know about marketing.</li>
                <li>Have research and analytical skills.</li>
                <li>Have good communication skills</li>
            </ol><br>
            <h2>Perks: </h2>
            <ol>
                <li>Certificate</li>
                <li>Informal Dress Code</li>
                <li>Flexible Working Hours</li>
                <li>Job Offer (on performance)</li>
            </ol>
            <h2>Contact Details of EDYoda - Zekelabs Technology:</h2>
            <ul>
                <li>Companies Website:https://university.edyoda.com/</li>
                <li>Contact Number: 02071173661</li>
                <li>Email: hello@edyoda.com</li>
                <li>Mailing address:<br>EDYoda, 2nd Floor #188, Survey No. 123/1<br>Incubes Building Next to McDonalds, ITPL Main Rd.<br>Brookefield, Bengaluru 560037<br>Karnataka, India</li>
            </ul><br><br>
            <button onclick="changeText(this)">Apply Now</button><br><br>
            <script>
                function changeText(id) {
                   id.innerHTML = "Applied";
                   alert("Your application Submitted");
                }
            </script>
        </main>
        <footer>
            <div class="left">
                <h2>Office Address:</h2>
                <p>B-161<br>Ashok Vihar<br>Delhi-110052<p>
            </div>
            <div class="main" style=" width: 30%; float: left">
                <a href="ourteam.php"">Our Team</a><br>
                <a href="aboutus.php">About Us</a><br>
                <a href="privacypolicy.php">Privacy Policy</a><br>
                <a href="termsnconditions.php">Terms and Conditions</a>
            </div>
            <div class="right">
                <h2>Contact Us:</h2>
                <p>+91 8826033672<br>+91 7718025123<br>+91 9869799006</p>
            </div>
        </footer>
    </body>
</html>