<?php

$con=mysqli_connect("localhost","root","","wpfinalproject") or die(mysqli_error($con));

session_start();
$email= mysqli_real_escape_string($con,$_POST['email']);
$password= mysqli_real_escape_string($con,$_POST['password']);

$s="SELECT * from user where Email='$email' && Password='$password'";
$res= mysqli_query($con, $s);
$num= mysqli_num_rows($res);

if($num>0){
    $row = mysqli_fetch_array($res);

    if (mysqli_num_rows($res) >= 1){
         header("location:homepage.php");
         $_SESSION["email"]=$email;
         $_SESSION["name"]=$row["Name"];
         $_SESSION["contact"]=$row["Contact"];
         $_SESSION["gender"]=$row["Gender"];
         $_SESSION["qualification"]=$row["Qualification"];
    }
 else {
       header("location:login.php");
 }
}
else{
     echo '<script>alert("Invalid Email or Password")</script>';
}

?>
