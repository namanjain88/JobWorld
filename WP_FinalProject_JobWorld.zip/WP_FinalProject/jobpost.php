<!DOCTYPE html>
<html lang="en-us">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title> Post a Job Opportunity </title>
        <link rel="stylesheet" href="jobspost.css">
        <script language="javascript" src="home.js"></script>
        <link rel="icon" href="favicon.png" type="image/x-icon"/>
         <script>
        function myFunction3() {
  document.getElementById("myDropdown3").classList.toggle("show3");
}

window.onclick = function(event) {
  if (!event.target.matches('.dropbtn3')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show3')) {
        openDropdown.classList.remove('show3');
      }
    }
  }
}</script>
</head>
<body>
     <nav id="nav">
        <ul>
            <li><i>JOBWORLD</i></li>
            <li><a href="homepage.php">HOME</a></li>
            <li><button onclick="myFunction()" class="dropbtn">JOBS</button> </li>
                <div id="myDropdown" class="dropdown-content">
                    <a href="alljobs.php">All Jobs</a>
                     <a href="jobsbycity.php">Jobs By City</a>
                     <a href="jobsbydomain.php">Jobs By Domain</a>
                </div>
           
             <li><button onclick="myFunction2()" class="dropbtn2">INTERNSHIPS</button> </li>
            <div id="myDropdown2" class="dropdown-content">
                <a href="allinternships.php">All Internships</a>
                     <a href="internshipbycity.php">Internships By City</a>
                     <a href="internshipbydomain.php">Internships By Domain</a>
                </div>
              
             <li><button onclick="myFunction3()" class="dropbtn3">POST</button></li>     
            <div id="myDropdown3" class="dropdown-content">
                <a href="jobpost.php">Post a Job</a>
                     <a href="PostInternship.php">Post an Internship</a>
                    
                </div>
             <li><a href="resumetemplates.php">RESUME</a></li>
            <li><a href="aboutus.php">ABOUT US</a></li>
            <li style="margin-left: 30%;"><a href="myprofile.php">MY PROFILE</a></li>
        </ul>
        </nav>
        
    <main>
    
    <h2 style="color:#3399FF; text-align: center;">Post a Job Opportunity</h2>
<form>
<p>About your Company:</p>
<label for='img'>Upload logo:</label><br>
<input type='file' id='img' name='img'><br><br>
Company Name:<br><input type='text' style='width:50%' placeholder='Enter Your Company name'><br><br>
Enter company's website:<br><input type='url' placeholder='For example: https://www.jobsworld.com' size='50'><br><br>
Company Profile:<br><textarea rows=6 cols=100 placeholder='For example: JobsWorld is an e-recruitement platform that helps organizations with their recruitement process. It also ensures safety for its users. Additionally, job seekers are also provided with features such as resume building, job filtering, finding internship opportunities etc.'></textarea><br><br>
Contact Details: -<br>
Number:<br><input type='number' placeholder="Enter representative's number" style='width:25em'><br><br>
E-mail Address:<br><input type='email' placeholder='Enter email address' size='50'><br><br>
Mailing Address:<br><textarea rows=5 cols=75 placeholder='Enter office address'></textarea><br><br>
<p>About the job opportunity:</p>
Job Title:<br><input type='text' style='width:50%' placeholder='Enter Job Title'><br><br>
Job Description:<br><textarea rows='5' cols='100' style='width:50%' placeholder="Job Description"></textarea><br><br>
Role Background:<br><input type=text placeholder='For example: software development' style='width:50%'><br><br>
Salary Range:<br>INR: <input type='number' style='width:75px'> per annum<br><br> 
Department:<br><input type=text placeholder='Enter Department of Job' style='width:50%'><br><br>
Employment Type:<br>
<input type="radio" name="employmenttype" value="fulltime">Full-Time <input type="radio" name="employmenttype" value="parttime">Part-Time<br><br>
Location:<br><input type='text' style='width:50%' placeholder='Enter Location for Job'><br><br>
Skills Required:<br><textarea rows='10' cols='50' placeholder="Skills Required"></textarea><br><br>
Preferred Qualification:<br><textarea rows=5 cols=75 placeholder='For example: Full Time Graduates / Post Graduates in: BE / BTech / ME / MTech / MSc / MCA / MCM / MS'></textarea><br><br>
Work Experience Required:<br><input type='text' style='width:50%' placeholder='Enter minimum years of work experience required. Enter 0 if freshers are eligible.'><br><br>
Added Advantage:<br><textarea rows='6' cols='45' placeholder='For example: Familiar with JS Libraries. Back-end Tools.'></textarea><br><br>
Last date for application:<br><input type="text" placeholder="Apply By" size='15' onfocus="(this.type='date')"><br><br>
Additional Information (if any):<br><textarea rows='6' cols='45' placeholder='Enter other important details for which no relevant space is allotted.'></textarea><br><br></textarea><br>
<button>SUBMIT</button>

</form>
    </main>
    
    <footer>
            <div class="left">
                <h2>Office Address:</h2>
                <p>B-161<br>Ashok Vihar<br>Delhi-110052<p>
            </div>
            <div class="main" style=" width: 30%; float: left">
                <a href="ourteam.php"">Our Team</a><br>
                <a href="aboutus.php">About Us</a><br>
                <a href="privacypolicy.php">Privacy Policy</a><br>
                <a href="termsnconditions.php">Terms and Conditions</a>
            </div>
            <div class="right">
                <h2>Contact Us:</h2>
                <p>+91 8826033672<br>+91 7718025123<br>+91 9869799006</p>
            </div>
        </footer>
</body>
