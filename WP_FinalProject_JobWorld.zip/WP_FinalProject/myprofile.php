<?php
session_start();
$con=mysqli_connect("localhost","root","","wpfinalproject") or die(mysqli_error($con));
$email=$_SESSION["email"];

?>
<html>
    <head>
        <title>JobWorld-Home</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="profile.css">
        <script language="javascript" src="home.js"></script>
        <link rel="icon" href="favicon.png" type="image/x-icon"/>
        <script>
        function myFunction3() {
  document.getElementById("myDropdown3").classList.toggle("show3");
}

window.onclick = function(event) {
  if (!event.target.matches('.dropbtn3')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show3')) {
        openDropdown.classList.remove('show3');
      }
    }
  }
}</script>
    </head>
    <body>
        <nav id="nav">
        <ul>
            <li><i>JOBWORLD</i></li>
            <li><a href="homepage.php">HOME</a></li>
            <li><button onclick="myFunction()" class="dropbtn">JOBS</button> </li>
                <div id="myDropdown" class="dropdown-content">
                    <a href="alljobs.php">All Jobs</a>
                     <a href="jobsbycity.php">Jobs By City</a>
                     <a href="jobsbydomain.php">Jobs By Domain</a>
                </div>
           
             <li><button onclick="myFunction2()" class="dropbtn2">INTERNSHIPS</button> </li>
            <div id="myDropdown2" class="dropdown-content">
                <a href="allinternships.php">All Internships</a>
                     <a href="internshipbycity.php">Internships By City</a>
                     <a href="internshipbydomain.php">Internships By Domain</a>
                </div>
              
             <li><button onclick="myFunction3()" class="dropbtn3">POST</button></li>     
            <div id="myDropdown3" class="dropdown-content">
                <a href="jobpost.php">Post a Job</a>
                     <a href="PostInternship.php">Post an Internship</a>
                    
                </div>
             <li><a href="resumetemplates.php" class="favourites">RESUME</a></li>
             <li><a href="aboutus.php">ABOUT US</a></li>
             <li style="margin-left: 30%;"><a href="myprofile.php">MY PROFILE</a></li>
        </ul>
        </nav>
        <h1 class="heading" style="text-align: center;">
        <span>P</span>
        <span>R</span>
        <span>O</span>
        <span>F</span>
        <span>I</span>
        <span>L</span>
        <span>E</span>
        
    </h1>
           <?php
            $result = $con->query("SELECT * FROM user where Email='$email'"); 

           if($result-> num_rows > 0){ ?> 
    <div class="gallery"> 
        <?php while($row = $result->fetch_assoc()){ ?> 
            <img src="data:image/jpg;charset=utf8;base64,<?php echo base64_encode($row['image']); ?>" /> 
        <?php } ?> 
    </div> 
<?php }else{ ?> 
    <p class="status error">Image(s) not found...</p> 
<?php }?>
    <h3 style="text-align: center; position: absolute; top: 300px; left: 45%; font-size: 130%;"><?php echo $_SESSION["name"];?></h3>
        <main>
         
            
            <p>Email: <?php echo $_SESSION["email"]; ?></p>
            <p>Contact: <?php echo $_SESSION["contact"]; ?></p>
            <p>Gender: <?php echo $_SESSION["gender"]; ?></p>
            <p>Qualification: <?php echo $_SESSION["qualification"]; ?></p><br>
            <input type="submit" value="LOGOUT" onclick="location.href='index.php'">
        </main>
        
    </body>
</html>
