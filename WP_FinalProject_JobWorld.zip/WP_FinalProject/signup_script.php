<?php
$conn=mysqli_connect("localhost","root","","wpfinalproject") or die(mysqli_error($conn));
session_start();
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$email= mysqli_real_escape_string($conn,$_POST['email']);
$name= mysqli_real_escape_string($conn,$_POST['name']);
$contact=$_POST["contact"];
$gender=$_POST["gender"];
$password=mysqli_real_escape_string($conn,$_POST['password']);
$password2=mysqli_real_escape_string($conn,$_POST['password2']);
$qualify=$_POST["qualif"];
if($password!=$password2){
    echo '<script>alert("Both Passwords Doesnt Match")</script>';
}
elseif (strlen($contact)!=10) {
     echo '<script>alert("Please Enter 10-digit contact number")</script>';
}
 elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo 'Please Enter Valid Email';
 
 }

else{

if(!empty($_FILES["image"]["name"])) { 
        // Get file info 
        $fileName = basename($_FILES["image"]["name"]); 
        $fileType = pathinfo($fileName, PATHINFO_EXTENSION); 
         
        // Allow certain file formats 
        $allowTypes = array('jpg','png','jpeg','gif'); 
        if(in_array($fileType, $allowTypes)){ 
            $image = $_FILES['image']['tmp_name']; 
            $imgContent = addslashes(file_get_contents($image)); 
         
            // Insert image content into database 
            $insert = $conn->query("INSERT INTO user(Name,Email,Contact,Gender,Qualification,Password,image) VALUES ('$name', '$email','$contact','$gender','$qualify','$password','$imgContent')"); 
             
            if($insert){ 
                header("Location: homepage.php");
                $_SESSION["name"]=$name;
                $_SESSION["email"]=$email;
                $_SESSION["gender"]=$gender;
                $_SESSION["contact"]=$contact;
                $_SESSION["qualification"]=$qualify;
              
            }
        
        }
}
}
    


 
 


?>

