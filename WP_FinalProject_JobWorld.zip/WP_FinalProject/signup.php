<html>
    <head>
        <title>Signup</title>
         <link rel="icon" href="favicon.png" type="image/x-icon"/>
         <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        .left{
            float: left;
            margin-left: 5%;
            width: 45%;
            background-color: black;
            opacity: 0.8;
            color: white;
            margin-top: 150px;
            height: 180px;
            padding-top: 100px;
            font-size: 20px;
            animation-name: popleft;
            animation-duration: 2s;
        }
            @keyframes popleft {
             0%   {margin-left:0%}
             100%  {margin-left:5%}
            }
        .panel{
            background-color: lightcyan;
            margin-right: 5%;
            float: right;
            width: 40%;
            opacity: 0.8;
            padding: 5px;           
            margin-top: 50px;
            height: 500px;
            animation-name: popright;
            animation-duration: 2s;
        }
        @keyframes popright {
             0%   {margin-right:0%}
             100%  {margin-right:5%}
            }
        .panel form{
            margin-top: 10px;
        }
        a{
            color: blue;
            text-decoration: none; 
        }
        body{
            text-align: center;
             background-image: url('cover2.jpg');
             background-repeat: no-repeat;
             background-size: cover;
        }
        button{
            background-color: blue; 
            color: white; 
            size: 100px;
        }
    </style>
     </head>
    <body>
        <div class="left">
            <p>"The average person puts only 25% of his energy into his work. The world takes off its hat to those who put in more than 50% of their capacity, and stands on its head for those few and far between souls who devote 100%.”</p>    
        </div>
      
        <div class="panel">
            <h1 style="color:blue; font-family: cursive;">SIGNUP</h1>
                <form action="signup_script.php" method="post" enctype="multipart/form-data">
                    <label>Enter Your Name: </label><input type="text" name="name" placeholder="Enter your name" required><br><br>
                    <label>Enter Your Email: </label><input type="email" name="email" placeholder="Enter email" required><br><br>
                    <label>Enter Your Contact: </label><input type="tel" name="contact" placeholder="Enter contact" required maxlength="10" minlength="10"><br><br>
                    <label>Select Your Gender:</label><input type="radio" name="gender" value="male">Male <input type="radio" name="gender" value="female">Female<br><br>
                    <label>Qualification: </label>
                    <select name="qualif" required>
                        <option value="none">--SELECT--</option>
                        <option value="Student">Student</option>
                        <option value="Graduate">Graduate</option>
                        <option value="Post Graduate">Post Graduate</option>
                        <option value="PHD Holder">PHD Holder</option>
                    </select><br><br>
                    <label>Enter Password: </label><input type="password" name="password" placeholder="Enter password" required><br><br>
                    <label>Confirm Password: </label><input type="password" name="password2" placeholder="Confirm password" required><br><br>
                    <label>Upload Your Image: </label>
                    <input type="file" name="image" value=""><br><br>  	
                    <input type="checkbox" name="accept" required>Accept Terms And Conditions<br><br>
                    <input type="submit" class="button" value="SIGNUP" style="background-color: blue; color: white; size: 100px;">
                    <input type="reset" value="CLEAR" onClick="return confirm('Are You Sure You want to Reset???')" style="background-color: blue; color: white; size: 100px;">
              </form>
        
        </div>
 
    </body>
</html>

