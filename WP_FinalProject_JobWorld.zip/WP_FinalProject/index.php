
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>JobWorld</title>
        <link rel="icon" href="favicon.png" type="image/x-icon"/>
        <style>
            button{
                width: 70%;
                height: 50px;
                background-color: blue;
                color: white;
                margin-top: 50px;
                margin-left: 15%;
            }
            button:hover{
               
                background-color: white;
                color: blue;
            }
            h1{
                margin-left: 35%;
                margin-right: 40%;
                color: blue;
                font-family: cursive;
                animation-name: example;
                animation-duration: 10s
            }
                
                @keyframes example {
             0%   {color:red;}
             12.5%  {color:black; transform: rotateZ(30deg);}
             25%  {color:blue; transform: rotateZ(0deg);}
             37.5%  {color:green; transform: rotateZ(-30deg);}
             50% {color:purple;}
             62.5%  {color:orange;transform: rotateZ(0deg);}
             75%  {color:darkyellow; }
             87.5%  {color:darkgrey;}
             100% {color:brown;}
            
            }
            body{
                background-image: url('cover2.jpg');
                background-repeat: no-repeat;
                background-size: cover;
                
            }
            .panel{
                margin: 10% 25% 0 25%;
                background-color: lightgray;
                opacity: 0.8;
            }
        </style>
    </head>
    <body>
       
        <div class="panel">
                <h1>JOBWORLD</h1>
                <h3 style="margin-left: 20%; color: black;">It's time to start living the life we've imagined!!</h3>
                <button onclick="location.href='login.php'">LOGIN</button>
                <button onclick="location.href='signup.php'" style=" margin-bottom: 20px; margin-top: 25px;">SIGNUP</button>
                    
             
        </div>
    </body>
</html>
