<html>
    <head>
        <title>All Jobs</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="homepage.css">
        <script language="javascript" src="home.js"></script>
        <link rel="icon" href="favicon.png" type="image/x-icon"/>
        <script>
        function myFunction3() {
  document.getElementById("myDropdown3").classList.toggle("show3");
}

window.onclick = function(event) {
  if (!event.target.matches('.dropbtn3')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show3')) {
        openDropdown.classList.remove('show3');
      }
    }
  }
}</script>
    <style>
        form input{
            margin-left: 30%;
            margin-top: 10px;
            width: 30%;
            height: 30px;
            border: solid;
            
        }
   
        </style>
    </head>
    <body>
        <nav id="nav">
        <ul>
            <li><i>JOBWORLD</i></li>
            <li><a href="homepage.php">HOME</a></li>
            <li><button onclick="myFunction()" class="dropbtn">JOBS</button> </li>
                <div id="myDropdown" class="dropdown-content">
                    <a href="alljobs.php">All Jobs</a>
                     <a href="jobsbycity.php">Jobs By City</a>
                     <a href="jobsbydomain.php">Jobs By Domain</a>
                </div>
           
             <li><button onclick="myFunction2()" class="dropbtn2">INTERNSHIPS</button> </li>
            <div id="myDropdown2" class="dropdown-content">
                <a href="allinternships.php">All Internships</a>
                     <a href="internshipbycity.php">Internships By City</a>
                     <a href="internshipbydomain.php">Internships By Domain</a>
                </div>
              
             <li><button onclick="myFunction3()" class="dropbtn3">POST</button></li>     
            <div id="myDropdown3" class="dropdown-content">
                <a href="jobpost.php">Post a Job</a>
                     <a href="PostInternship.php">Post an Internship</a>
                    
                </div>
             <li><a href="resumetemplates.php" class="favourites">RESUME</a></li>
             <li><a href="aboutus.php">ABOUT US</a></li>
             <li style="margin-left: 30%;"><a href="myprofile.php">MY PROFILE</a></li>
        </ul>
        </nav>
                <h1 style="text-align: center; font-family: cursive; color: #3399FF; margin-top: 50px; font-size: 50px;">Management Internships</h1>

        <div class="job"> 
             <img src="wipro.png" alt="Wipro">
                <h2>Wipro<br>(Management)</h2><br><br>
                <ul>
                    <li>Start Date: 15 November 2021</li>
                    <li>Stipend: 9000/-</li>
                    <li>Duration: 3 months</li>
                    <li>Location: Mumbai</li>
                </ul>
                <button>Know More</button>
        </div>
        <div class="job"> 
             <img src="edy.png" alt="EdYoda - Zekelabs Technology">
             <h2>EdYoda - Zekelabs Technology<br>(Business Development - Sales)</h2><br><br>
                <ul>
                    <li>Start Date: 25 November 2021</li>
                    <li>Stipend: 12500/-</li>
                    <li>Duration: 3 month</li>
                    <li>Location: Bangalore</li>
                </ul>
                <button>Know More</button>
        </div>
         <div class="job"> 
             <img src="block.png" alt="BLOCK X">
             <h2>BLOCK X<br>(Business Strategy)</h2><br><br>
                <ul>
                    <li>Start Date: 25 November 2021</li>
                    <li>Stipend: 5000/-</li>
                    <li>Duration: 2 month</li>
                    <li>Location: Chennai</li>
                </ul>
                <button>Know More</button>
        </div>
        <div class="job" style="margin-top: 50px;"> 
                <img src="urbancompany.png" alt="Urban Company">
                <h2>Urban Company<br>(Operational Management)</h2><br><br>
                  
                <ul>
                    <li>Start Date: Starts Immediately</li>
                    <li>Stipend: 10000/-</li>   
                    <li>Duration: 3 months</li>
                    <li>Location: Mumbai</li>
                </ul>
                <button onclick="location.href=''">Know More</button>
               
        </div>
         <div class="job"> 
             <img src="online.png" alt="Online Live Learning">
                <h2>Online Live Learning<br>(Product Management)</h2><br><br>
                <ul>
                    <li>Start Date: Starts Immediately</li>
                    <li>Salary: 15000/-</li>
                    <li>Duration: 6 month</li>
                    <li>Location: Work from Home</li>
                </ul>
                <button>Know More</button>
        </div>
        

        
        <footer>
            <div class="left">
                <h2>Office Address:</h2>
                <p>B-161<br>Ashok Vihar<br>Delhi-110052<p>
            </div>
            <div class="main" style=" width: 30%; float: left">
                <a href="ourteam.php"">Our Team</a><br>
                <a href="aboutus.php">About Us</a><br>
                <a href="privacypolicy.php">Privacy Policy</a><br>
                <a href="termsnconditions.php">Terms and Conditions</a>
            </div>
            <div class="right">
                <h2>Contact Us:</h2>
                <p>+91 8826033672<br>+91 7718025123<br>+91 9869799006</p>
            </div>
        </footer>
    </body>
</html>