<html>
    <head>
        <title>Resume Templates</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="resume.css">
        <script language="javascript" src="home.js"></script>
        <link rel="icon" href="favicon.png" type="image/x-icon"/>
                <script>
        function myFunction3() {
  document.getElementById("myDropdown3").classList.toggle("show3");
}

window.onclick = function(event) {
  if (!event.target.matches('.dropbtn3')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show3')) {
        openDropdown.classList.remove('show3');
      }
    }
  }
}</script>
    </head>
    <body>
        <nav>
        <ul>
            <li><i>JOBWORLD</i></li>
            <li><a href="homepage.php">HOME</a></li>
            <li><button onclick="myFunction()" class="dropbtn">JOBS</button> </li>
                <div id="myDropdown" class="dropdown-content">
                    <a href="alljobs.php">All Jobs</a>
                     <a href="jobsbycity.php">Jobs By City</a>
                     <a href="jobsbydomain.php">Jobs By Domain</a>
                </div>
           
             <li><button onclick="myFunction2()" class="dropbtn2">INTERNSHIPS</button> </li>
            <div id="myDropdown2" class="dropdown-content">
                <a href="allinternships.php">All Internships</a>
                     <a href="internshipbycity.php">Internships By City</a>
                     <a href="internshipbydomain.php">Internships By Domain</a>
                </div>
             <li><button onclick="myFunction3()" class="dropbtn3">POST</button></li>     
            <div id="myDropdown3" class="dropdown-content">
                <a href="jobpost.php">Post a Job</a>
                <a href="PostInternship.php">Post an Internship</a>
                    
                </div>
             <li><a href="resumetemplates.php">RESUME</a></li>
            <li><a href="aboutus.php">ABOUT US</a></li>
            <li style="margin-left: 30%;"><a href="myprofile.php">MY PROFILE</a></li>
        </ul>
        </nav>
        <header>
              <h1 class="heading" style="text-align: center;">
        <span>R</span>
        <span>E</span>
        <span>S</span>
        <span>U</span>
        <span>M</span>
        <span>E</span><br><br>
        <span>T</span>
        <span>E</span>
        <span>M</span>
        <span>P</span>
        <span>L</span>
        <span>A</span>
        <span>T</span>
        <span>E</span>
        <span>S</span>
    </h1>
        </header>
        <main>
            <div class="left">
                <figure>
                    <img src="resume1.PNG" alt="resume1">
                    <figcaption>
                        <h3>Resume Template 1</h3>
                        <a href="Resume1.docx" download>DOWNLOAD</a>
                    </figcaption>
                </figure>
            </div>
            <div class="right">
                <figure>
                    <img src="resume2.PNG" alt="resume2">
                    <figcaption>
                        <h3>Resume Template 2</h3>
                        <a href="resume2.docx" download>DOWNLOAD</a>
                    </figcaption>
                </figure>
            </div>
             <div class="left">
                <figure>
                    <img src="resume3.PNG" alt="resume3">
                    <figcaption>
                        <h3>Resume Template 3</h3>
                        <a href="resume3.docx" download>DOWNLOAD</a>
                    </figcaption>
                </figure>
            </div>
            <div class="right">
                <figure>
                    <img src="resume4.PNG" alt="resume4">
                    <figcaption>
                        <h3>Resume Template 4</h3>
                        <a href="resume4.docx" download>DOWNLOAD</a>
                    </figcaption>
                </figure>
            </div>
            <div class="left">
                <figure>
                    <img src="resume5.PNG" alt="resume5">
                    <figcaption>
                        <h3>Resume Template 5</h3>
                        <a href="resume5.docx" download>DOWNLOAD</a>
                    </figcaption>
                </figure>
            </div>
            <div class="right">
                <figure>
                    <img src="resume6.PNG" alt="resume6">
                    <figcaption>
                        <h3>Resume Template 6</h3>
                        <a href="resume6.docx" download>DOWNLOAD</a>
                    </figcaption>
                </figure>
            </div>
        </main>
        <footer>
            <div class="left">
                <h2>Office Address:</h2>
                <p>B-161<br>Ashok Vihar<br>Delhi-110052<p>
            </div>
            <div class="main" style=" width: 30%; float: left">
                <a href="ourteam.php"">Our Team</a><br>
                <a href="aboutus.php">About Us</a><br>
                <a href="privacypolicy.php">Privacy Policy</a><br>
                <a href="termsnconditions.php">Terms and Conditions</a>
            </div>
            <div class="right">
                <h2>Contact Us:</h2>
                <p>+91 8826033672<br>+91 7718025123<br>+91 9869799006</p>
            </div>
        </footer>
        
    </body>
</html>
