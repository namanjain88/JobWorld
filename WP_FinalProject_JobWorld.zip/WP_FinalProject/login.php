
<html>
    <head>
        <title>Login</title>
         <link rel="icon" href="favicon.png" type="image/x-icon"/>
         <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        .left{
            float: left;
            margin-left: 5%;
            width: 45%;
            background-color: black;
            opacity: 0.8;
            color: white;
            margin-top: 150px;
            height: 180px;
            padding-top: 120px;
            font-size: 20px;
            animation-name: popleft;
            animation-duration: 2s;
        }
            @keyframes popleft {
             0%   {margin-left:0%}
             100%  {margin-left:5%}
            }
        .panel{
            background-color: lightcyan;
            margin-right: 5%;
            float: right;
            width: 40%;
            opacity: 0.8;
            padding: 5px;
            text-align: center;
            margin-top: 150px;
            height: 300px;
            animation-name: popright;
            animation-duration: 2s;
        }
        @keyframes popright {
             0%   {margin-right:0%}
             100%  {margin-right:5%}
            }
        .panel form{
            margin-top: 10px;
            margin-left: 5%;
            margin-right: 5%;
        }
        a{
            color: blue;
            text-decoration: none; 
        }
        body{
            text-align: center;
             background-image: url('cover2.jpg');
             background-repeat: no-repeat;
             background-size: cover;
        }
        button{
            background-color: blue; 
            color: white; 
            size: 100px;
        }
    </style>
     </head>
    <body>
        <div class="left">
            <p>“Believe in yourself! Have faith in your abilities! Without a humble but reasonable confidence in your own powers you cannot be successful or happy.”</p>    
        </div>
      
        <div class="panel">
            <h1 style="color:blue; font-family: cursive;">LOGIN</h1>
            <form action="login_script.php" method="post">
                <label>Email:</label>
                <input type="email" name="email" style="margin-left: 15px;"><br><br>
                <label>Password:</label>
                <input type="password" name="password"><br><br>            
                <input type="submit" class="button" value="LOGIN" style="background-color: blue; color: white; size: 100px;"><br>
                <a href="forgotpassword.php">Forgot Password?</a>
              </form>
        
        </div>
 
    </body>
</html>