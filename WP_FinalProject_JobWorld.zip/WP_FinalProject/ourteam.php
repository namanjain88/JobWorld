<!DOCTYPE html>
<html>
    <head>
        <title>Our Team</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="ourteam.css">
        <script language="javascript" src="home.js"></script>
        <link rel="icon" href="favicon.png" type="image/x-icon"/>
                <script>
        function myFunction3() {
  document.getElementById("myDropdown3").classList.toggle("show3");
}

window.onclick = function(event) {
  if (!event.target.matches('.dropbtn3')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show3')) {
        openDropdown.classList.remove('show3');
      }
    }
  }
}</script>
    </head>
    <body>
         <nav>
        <ul>
            <li><i>JOBWORLD</i></li>
            <li><a href="homepage.php">HOME</a></li>
            <li><button onclick="myFunction()" class="dropbtn">JOBS</button> </li>
                <div id="myDropdown" class="dropdown-content">
                    <a href="alljobs.php">All Jobs</a>
                     <a href="jobsbycity.php">Jobs By City</a>
                     <a href="jobsbydomain.php">Jobs By Domain</a>
                </div>
           
             <li><button onclick="myFunction2()" class="dropbtn2">INTERNSHIPS</button> </li>
                <div id="myDropdown2" class="dropdown-content">
                    <a href="allinternships.php">All Internships</a>
                     <a href="internshipbycity.php">Internships By City</a>
                     <a href="internshipbydomain.php">Internships By Domain</a>
                </div>
              <li><button onclick="myFunction3()" class="dropbtn3">POST</button></li>     
            <div id="myDropdown3" class="dropdown-content">
                <a href="jobpost.php">Post a Job</a>
                     <a href="PostInternship.php">Post an Internship</a>
                    
                </div>
              <li><a href="resumetemplates.php">RESUME</a></li>
            <li><a href="aboutus.php">ABOUT US</a></li>
            <li style="margin-left: 30%;"><a href="myprofile.php">MY PROFILE</a></li>
        </ul>
        </nav>
        <main>
         <h1 class="heading" style="text-align: center;">
        <span>A</span>
        <span>B</span>
        <span>O</span>
        <span>U</span>
        <span>T</span>
        <span>U</span>
        <span>S</span>
        
    </h1>
        <div class="intro">
            <p>We, the students of MPSTME Shirpur MBATech CS 3rd Year(2021-22) built this website as mini project in Web Programming.</p>
            <p>This website allows students and employees to search for desired internships and jobs per their interest, moreover it allows employers to post a new listing of job or internship.   </p>
        </div>
    <h1 class="heading" style="text-align: center;">
        <span>O</span>
        <span>U</span>
        <span>R</span>
        <span>T</span>
        <span>E</span>
        <span>A</span>
        <span>M</span>
        
    </h1>
        <div class="naman">
            <figure>
            <img src="naman5.jpeg" alt="Naman Jain"><br>
            <figcaption>
                <h2>Naman Jain</h2>
                <h3>N242--70471119043</h3>
                <a href="https://www.linkedin.com/in/naman-jain-84567a1b3" target="_blank" title="Click Here to Follow Naman on LinkedIN"><img src="linkedin.png" alt="LN" style="height: 20px; width: 20px; margin-top: 0; border-radius: 0;"></a>
                <a href="https://www.instagram.com/namanjain_13/?r=nametag" target="_blank" title="Click Here to Follow Naman on Instagram"><img src="insta.jpg" alt="IN" style="height: 20px; width: 20px; margin-top: 0; border-radius: 0;"></a>
                <a href="https://github.com/namanjain88" target="_blank" title="Click Here to Follow Naman on Github"><img src="github.png" alt="GH" style="height: 20px; width: 25px; margin-top: 0; border-radius: 0;"></a>
            </figcaption>
            </figure>
        </div>
        <div class="anshool">
            <figure>
             <img src="anshool.jpeg" alt="Anshool Aggrwal"><br>
            <figcaption>
                <h2>Anshool Aggarwal</h2>
                <h3>N204--70471119004</h3>
                <a href="http://Linkedin.com/in/anshool-agarwal-93ba791a0/" target="_blank" title="Click Here to Follow Anshool on LinkedIN"><img src="linkedin.png" alt="LN" style="height: 20px; width: 20px; margin-top: 0; border-radius: 0;"></a>
                <a href="https://www.instagram.com/agrawalanshool/" target="_blank" title="Click Here to Follow Anshool on Instagram"><img src="insta.jpg" alt="IN" style="height: 20px; width: 20px; margin-top: 0; border-radius: 0;"></a>
                <a href="" target="_blank" title="Click Here to Follow Anshool on Github"><img src="github.png" alt="GH" style="height: 20px; width: 25px; margin-top: 0; border-radius: 0;"></a>
            </figcaption>
            </figure>
        </div>
        <div class="ayush">
            <figure>
                <img src="ayush.jpeg" alt="Ayush Jain"><br>
            <figcaption>
                <h2>Ayush Jain</h2>
                <h3>N239--70471119040</h3>
                <a href="https://www.linkedin.com/in/ayush-jain-13618a210/" target="_blank" title="Click Here to Follow Ayush on LinkedIN"><img src="linkedin.png" alt="LN" style="height: 20px; width: 20px; margin-top: 0; border-radius: 0;"></a>
                <a href="https://www.instagram.com/ayushjaiin_/" target="_blank" title="Click Here to Follow Ayush on Instagram"><img src="insta.jpg" alt="IN" style="height: 20px; width: 20px; margin-top: 0; border-radius: 0;"></a>
                <a href="" target="_blank" title="Click Here to Follow Ayush on Github"><img src="github.png" alt="GH" style="height: 20px; width: 25px; margin-top: 0; border-radius: 0;"></a>
            </figcaption>
            </figure>
        </div>
            
        <footer>
            <div class="left">
                <h2>Office Address:</h2>
                <p>B-161<br>Ashok Vihar<br>Delhi-110052<p>
            </div>
            <div class="main" style=" width: 30%; float: left">
                <a href="ourteam.php"">Our Team</a><br>
                <a href="aboutus.php">About Us</a><br>
                <a href="privacypolicy.php">Privacy Policy</a><br>
                <a href="termsnconditions.php">Terms and Conditions</a>
            </div>
            <div class="right">
                <h2>Contact Us:</h2>
                <p>+91 8826033672<br>+91 7718025123<br>+91 9869799006</p>
            </div>
        </footer>

            
        
    </body>
</html>
