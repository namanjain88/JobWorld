<html>
    <head>
        <title>Work From Home Internships</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="homepage.css">
        <script language="javascript" src="home.js"></script>
        <link rel="icon" href="favicon.png" type="image/x-icon"/>
        <script>
        function myFunction3() {
  document.getElementById("myDropdown3").classList.toggle("show3");
}

window.onclick = function(event) {
  if (!event.target.matches('.dropbtn3')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show3')) {
        openDropdown.classList.remove('show3');
      }
    }
  }
}</script>
    <style>
        form input{
            margin-left: 30%;
            margin-top: 10px;
            width: 30%;
            height: 30px;
            border: solid;
            
        }

   
        </style>
    </head>
    <body>
        <nav id="nav">
        <ul>
            <li><i>JOBWORLD</i></li>
            <li><a href="homepage.php">HOME</a></li>
            <li><button onclick="myFunction()" class="dropbtn">JOBS</button> </li>
                <div id="myDropdown" class="dropdown-content">
                    <a href="alljobs.php">All Jobs</a>
                     <a href="jobsbycity.php">Jobs By City</a>
                     <a href="jobsbydomain.php">Jobs By Domain</a>
                </div>
           
             <li><button onclick="myFunction2()" class="dropbtn2">INTERNSHIPS</button> </li>
            <div id="myDropdown2" class="dropdown-content">
                <a href="allinternships.php">All Internships</a>
                     <a href="internshipbycity.php">Internships By City</a>
                     <a href="internshipbydomain.php">Internships By Domain</a>
                </div>
              
             <li><button onclick="myFunction3()" class="dropbtn3">POST</button></li>     
            <div id="myDropdown3" class="dropdown-content">
                <a href="jobpost.php">Post a Job</a>
                     <a href="PostInternship.php">Post an Internship</a>
                    
                </div>
             <li><a href="resumetemplates.php" class="favourites">RESUME</a></li>
             <li><a href="aboutus.php">ABOUT US</a></li>
             <li style="margin-left: 30%;"><a href="myprofile.php">MY PROFILE</a></li>
        </ul>
        </nav>
        
        <h1 style="text-align: center; font-family: cursive; color: #3399FF; margin-top: 50px; font-size: 50px;">Work From Home Internships</h1>
       
        
        <div class="job" style="margin-top: 50px;"> 
                <img src="lk.png" alt="L.K. Stones">
                <h2>L.K. Stones<br>(Digital Marketing)</h2><br><br>
                  
                <ul>
                    <li>Start Date: Starts Immediately</li>
                    <li>Stipend: 3000/-</li>   
                    <li>Duration: 1 months</li>
                    <li>Location: Work from Home</li>
                </ul>
                <button onclick="location.href=''">Know More</button>
               
        </div>
	<br><br>
         <div class="job"> 
             <img src="nlr.png" alt="NLR India Foundation">
                <h2>NLR India Foundation<br>(Content Writing)</h2><br><br>
                <ul>
                    <li>Start Date: 20 October 2021</li>
                    <li>Stipend: 1000/-</li>
                    <li>Duration: 2 month</li>
                    <li>Location: Work from Home</li>
                </ul>
                <button>Know More</button>
        </div>
	<br><br>
             <div class="job"> 
                 <img src="auum.png" alt="AUUM Platforms">
                <h2>AUUM Platforms<br>(Operations)</h2><br><br>
                <ul>
                    <li>Start Date: 2 November 2021</li>
                    <li>Stipend: 5000/-</li>
                    <li>Duration: 2 months</li>
                    <li>Location: Work from Home</li>
                </ul>
                <button>Know More</button>
        </div>
	<br><br>
         <div class="job"> 
             <img src="cake.png" alt="Cake Mail">
                <h2>Cake Mail<br>(Human Resources)</h2><br><br>
                <ul>
                    <li>Start Date: Start Immediately</li>
                    <li>Stipend: 5000/-</li>
                    <li>Duration: 6 months</li>
                    <li>Location: Work from Home</li>
                </ul>
                <button>Know More</button>
        </div>
        <br><br>
         <div class="job"> 
             <img src="Minibox.png" alt="Miniboxoffice">
                <h2>Miniboxoffice<br>(Video Editing)</h2><br><br>
                <ul>
                    <li>Start Date: 2 November 2021</li>
                    <li>Salary: 1000/-</li>
                    <li>Duration: 1 months</li>
                    <li>Location: Work from Home </li>
                </ul>
                <button>Know More</button>
        </div>
	<br><br>
         <div class="job"> 
             <img src="jec.png" alt="JEC Publication">
                <h2>JEC Publication<br>(Web Development)</h2><br><br>
                <ul>
                    <li>Start Date: 1 November 2021</li>
                    <li>Stipend: 1000/-</li>
                    <li>Duration: 1 months</li>
                    <li>Location: Work from Home</li>
                </ul>
                <button>Know More</button>
        </div>
	<br><br>
         <div class="job"> 
             <img src="road.png" alt="Roadson Motors Pvt. Ltd.">
                <h2>Roadson Motors Pvt. Ltd.<br>(Graphic Design)</h2><br><br>
                <ul>
                    <li>Start Date: Start Immediately</li>
                    <li>Stipend: 5000/-</li>
                    <li>Duration: 2 months</li>
                    <li>Location: Work from Home</li>
                </ul>
                <button>Know More</button>
        </div>
	<br><br>
         <div class="job"> 
             <img src="online.png" alt="Online Live Learning">
                <h2>Online Live Learning<br>(Product Management)</h2><br><br>
                <ul>
                    <li>Start Date: Starts Immediately</li>
                    <li>Salary: 15000/-</li>
                    <li>Duration: 6 month</li>
                    <li>Location: Work from Home</li>
                </ul>
                <button>Know More</button>
        </div>
	<br><br>
         <div class="job"> 
             <img src="botx.png" alt="Botx Automations Pvt. Ltd.">
                <h2>Botx Automations Pvt. Ltd.<br>(UI/UX Design)</h2><br><br>
                <ul>
                    <li>Start Date: 30 November 2021</li>
                    <li>Salary: 1200/-</li>
                    <li>Duration: 6 month</li>
                    <li>Location: Work from Home</li>
                </ul>
                <button>Know More</button>
        </div>
        <br><br>
         <div class="job"> 
             <img src="digita.png" alt="DigitaArch.com">
                <h2>DigitaArch.com<br>(Business Development - Sales)</h2><br><br>
                <ul>
                    <li>Start Date: Start Immediately</li>
                    <li>Salary: 10000/-</li>
                    <li>Duration: 1 month</li>
                    <li>Location: Work from Home</li>
                </ul>
                <button>Know More</button>
        </div>
	<br><br>
        <div class="job"> 
            <img src="oddy.png" alt="Oddy Labs">
                <h2>Oddy Labs<br>(Blogging)</h2><br><br>
                <ul>
                    <li>Start Date: 3 November 2022</li>
                    <li>Stipend: 4000/-</li>
                    <li>Duration: 6 months</li>
                    <li>Location: Work from Home</li>
                </ul>
                <button>Know More</button>
        </div>
	<br><br>
        
        
        <footer>
            <div class="left">
                <h2>Office Address:</h2>
                <p>B-161<br>Ashok Vihar<br>Delhi-110052<p>
            </div>
            <div class="main" style=" width: 30%; float: left">
                <a href="ourteam.php"">Our Team</a><br>
                <a href="aboutus.php">About Us</a><br>
                <a href="privacypolicy.php">Privacy Policy</a><br>
                <a href="termsnconditions.php">Terms and Conditions</a>
            </div>
            <div class="right">
                <h2>Contact Us:</h2>
                <p>+91 8826033672<br>+91 7718025123<br>+91 9869799006</p>
            </div>
        </footer>

    </body>
</html>
