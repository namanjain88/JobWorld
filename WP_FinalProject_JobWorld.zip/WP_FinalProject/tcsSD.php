<html>
    <head>
        <title>JobWorld-TCS</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="amazonWD.css">
        <script language="javascript" src="home.js"></script>
        <link rel="icon" href="favicon.png" type="image/x-icon"/>
        <script>
        function myFunction3() {
  document.getElementById("myDropdown3").classList.toggle("show3");
}

window.onclick = function(event) {
  if (!event.target.matches('.dropbtn3')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show3')) {
        openDropdown.classList.remove('show3');
      }
    }
  }
}</script>
    </head>
    <body>
         <nav id="nav">
        <ul>
            <li><i>JOBWORLD</i></li>
            <li><a href="homepage.php">HOME</a></li>
            <li><button onclick="myFunction()" class="dropbtn">JOBS</button> </li>
                <div id="myDropdown" class="dropdown-content">
                    <a href="alljobs.php">All Jobs</a>
                     <a href="jobsbycity.php">Jobs By City</a>
                     <a href="jobsbydomain.php">Jobs By Domain</a>
                </div>
           
             <li><button onclick="myFunction2()" class="dropbtn2">INTERNSHIPS</button> </li>
            <div id="myDropdown2" class="dropdown-content">
                <a href="allinternships.php">All Internships</a>
                     <a href="internshipbycity.php">Internships By City</a>
                     <a href="internshipbydomain.php">Internships By Domain</a>
                </div>
              
             <li><button onclick="myFunction3()" class="dropbtn3">POST</button></li>     
            <div id="myDropdown3" class="dropdown-content">
                <a href="jobpost.php">Post a Job</a>
                     <a href="PostInternship.php">Post an Internship</a>
                    
                </div>
             <li><a href="resumetemplates.php">RESUME</a></li>
            <li><a href="aboutus.php">ABOUT US</a></li>
            <li style="margin-left: 30%;"><a href="myprofile.php">MY PROFILE</a></li>
        </ul>
        </nav>
        <h1 style="color: blue; font-family: cursive; text-align: center;">Internship at TCS (Software Development)</h1>
        <main>
            <img src="tcs.png" alt='Tata Consultancy Services'>
            <h2>Software Development<br>Tata Consultancy Services</h2>
             <ul>
                    <li>Start Date: 20 November 2021</li>
                    <li>Salary: 15000</li>
                    <li>Duration: 1 month</li>
                    <li>Location: Bangalore</li>
            </ul>
            <h2>About TCS:</h2>
            <p>Tata Consultancy Services (TCS) is an Indian multinational information technology (IT) services and consulting company headquartered in Mumbai, Maharashtra, India with its largest campus located in Chennai, Tamil Nadu, India. As of February 2021, TCS is the largest IT services company in the world by market capitalisation ($200 billion). It is a subsidiary of the Tata Group and operates in 149 locations across 46 countries.</p>
            <br>
            <h2>Internship Description:</h2>
            <p>Selected interns's day-to-day responsibilities include:</p>
            <ol>
                <li>Handle front-end/ back-end design and development as per project needs.</li>
                <li>Research on third party APIs to evaluate and integrate with our application</li>
                <li>Write server side automation scripts in a production environment</li>
            </ol><br>
            <h2>Who can Apply:</h2>
            <ol>
                <li>Are availbale for full time in-office Internship</li>
                <li>Pursuing 3rd or 4th year in Technology or equivalent graduation</li>
                <li>Are proficient in Coding Languages </li>
                <li>Able to solve complex problems</li>
            </ol><br>
            <h2>Perks: </h2>
            <ol>
                <li>Certificate</li>
                <li>Letter of Recommendation</li>
                <li>Free snacks and beverages</li>
            </ol>
            <h2>Contact Details of TCS:</h2>
            <ul>
                <li>Companies Website: www.tcs.com</li>
                <li>Contact Number: +91-796703700</li>
                <li>Email: contact.us@tcs.com</li>
                <li>Mailing address:<br>TCS house, Raveline Street<br> Fort, Mumbai 400001<br>Maharashtra, India</li>
            </ul><br><br>
            <button onclick="changeText(this)">Apply Now</button><br><br>
            <script>
                function changeText(id) {
                   id.innerHTML = "Applied";
                   alert("Your application Submitted");
                }
            </script>
        </main>
        <footer>
            <div class="left">
                <h2>Office Address:</h2>
                <p>B-161<br>Ashok Vihar<br>Delhi-110052<p>
            </div>
            <div class="main" style=" width: 30%; float: left">
                <a href="ourteam.php"">Our Team</a><br>
                <a href="aboutus.php">About Us</a><br>
                <a href="privacypolicy.php">Privacy Policy</a><br>
                <a href="termsnconditions.php">Terms and Conditions</a>
            </div>
            <div class="right">
                <h2>Contact Us:</h2>
                <p>+91 8826033672<br>+91 7718025123<br>+91 9869799006</p>
            </div>
        </footer>
    </body>
</html>