<html>
    <head>
        <title>ChangePassword</title>
        <link rel="icon" href="favicon.png" type="image/x-icon"/>
           <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        .left{
            float: left;
            margin-left: 5%;
            width: 45%;
            background-color: black;
            opacity: 0.8;
            color: white;
            margin-top: 150px;
            height: 180px;
            padding-top: 120px;
            font-size: 20px;
            animation-name: popleft;
            animation-duration: 2s;
        }
            @keyframes popleft {
             0%   {margin-left:0%}
             100%  {margin-left:5%}
            }
        .panel{
            background-color: lightcyan;
            margin-right: 5%;
            float: right;
            width: 40%;
            opacity: 0.8;
            padding: 5px;
            text-align: center;
            margin-top: 150px;
            height: 300px;
            animation-name: popright;
            animation-duration: 2s;
        }
        @keyframes popright {
             0%   {margin-right:0%}
             100%  {margin-right:5%}
            }
        .panel form{
            margin-top: 10px;
            margin-left: 5%;
            margin-right: 5%;
        }
        a{
            color: blue;
            text-decoration: none; 
        }
        body{
            text-align: center;
             background-image: url('cover2.jpg');
             background-repeat: no-repeat;
             background-size: cover;
        }
        #button{
            background-color: blue; 
            color: white; 
            size: 100px;
        }
    </style>
     </head>
    <body>
        <div class="left">
            <p>“When one door closes, another opens; but we often look so long and so regretfully upon the closed door that we do not see the one which has opened for us.”</p>    
        </div>
      
        <div class="panel">
            <h1 style="color:blue; font-family: cursive;">Change Password</h1>
            <form action="changepasswordscript.php" method="post">
                <label>Email:</label>
                <input type="email" name="email" style="margin-left: 90px;"><br><br>
                <label>New Password:</label>
                <input type="password" name="password1" style="margin-left: 35px;"><br><br>
                <label>Re-enter Password:</label>
                <input type="password" name="password2" style="margin-left: 10px;"><br><br>
                <input type="submit" name="Change" value="Change" id="button">
              </form>
        
        </div>
 
    </body>
</html>
