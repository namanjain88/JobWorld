<html>
    <head>
        <title>JobWorld-Amazon</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="amazonWD.css">
        <script language="javascript" src="home.js"></script>
        <link rel="icon" href="favicon.png" type="image/x-icon"/>
        <script>
        function myFunction3() {
  document.getElementById("myDropdown3").classList.toggle("show3");
}

window.onclick = function(event) {
  if (!event.target.matches('.dropbtn3')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show3')) {
        openDropdown.classList.remove('show3');
      }
    }
  }
}</script>
    </head>
    <body>
         <nav id="nav">
        <ul>
            <li><i>JOBWORLD</i></li>
            <li><a href="homepage.php">HOME</a></li>
            <li><button onclick="myFunction()" class="dropbtn">JOBS</button> </li>
                <div id="myDropdown" class="dropdown-content">
                    <a href="alljobs.php">All Jobs</a>
                     <a href="jobsbycity.php">Jobs By City</a>
                     <a href="jobsbydomain.php">Jobs By Domain</a>
                </div>
           
             <li><button onclick="myFunction2()" class="dropbtn2">INTERNSHIPS</button> </li>
            <div id="myDropdown2" class="dropdown-content">
                <a href="allinternships.php">All Internships</a>
                     <a href="internshipbycity.php">Internships By City</a>
                     <a href="internshipbydomain.php">Internships By Domain</a>
                </div>
              
             <li><button onclick="myFunction3()" class="dropbtn3">POST</button></li>     
            <div id="myDropdown3" class="dropdown-content">
                <a href="jobpost.php">Post a Job</a>
                     <a href="PostInternship.php">Post an Internship</a>
                    
                </div>
             <li><a href="resumetemplates.php">RESUME</a></li>
            <li><a href="aboutus.php">ABOUT US</a></li>
            <li style="margin-left: 30%;"><a href="myprofile.php">MY PROFILE</a></li>
        </ul>
        </nav>
        <h1 style="color: blue; font-family: cursive; text-align: center;">Web Development Job at Amazon</h1>
        <main>
            <img src="amazon.png" alt='amazon'>
            <h2>Web Development<br>Amazon</h2>
             <ul>
                    <li>Start Date: 20 November 2021</li>
                    <li>Salary: 15LPA</li>
                    <li>Work Experience: 5 year</li>
                    <li>Location: Mumbai</li>
                    <li>Employment type: Full-Time</li><br>
            </ul>
            <h2>About Amazon</h2>
            <p>Amazon is guided by four principles: customer obsession rather than competitor focus, passion for invention, commitment to operational excellence, and long-term thinking. Amazon strives to be Earth’s most customer-centric company, Earth’s best employer, and Earth’s safest place to work. Customer reviews, 1-Click shopping, personalized recommendations, Prime, Fulfillment by Amazon, AWS, Kindle Direct Publishing, Kindle, Career Choice, Fire tablets, Fire TV, Amazon Echo, Alexa, Just Walk Out technology, Amazon Studios, and The Climate Pledge are some of the things pioneered by Amazon.</p>
            <br>
            <h2>Job Description:</h2>
            <p>Selected employee's day-to-day responsibilities include:</p>
            <ol>
                <li>Handling the present website of Amazon India and making it faster</li>
                <li>Creating a dynamic function on the website (creative content on a daily basis)</li>
                <li>Creating new websites</li>
            </ol><br>
            <h2>Skills Required:</h2>
            <ol>
                <li>HTML</li>
                <li>CSS</li>
                <li>Javascript</li>
                <li>ReactJS</li>
            </ol><br>
            <h2>Preferred Qualification:</h2>
            <p>Should completed Graduation in <u>B.Tech/B.E/B.SC</u></p><br>
            <h2>Work Experience Required:</h2>
            <p>Minimum <mark>5 years</mark> after graduation</p>
            <h2>Added Advantages:</h2>
            <ol>
                <li>New Car at time of joining</li>
                <li>Transportation Facility</li>
                <li>Monthly Dayout</li>
            </ol>
            <h2>Last Date to Apply:</h2>
            <p>15 October 2021</p>
            <h2>Contact Details of Amazon:</h2>
            <ul>
                <li>Companies Website: www.amazon.in</li>
                <li>Contact Number: 011 274522568</li>
                <li>Email:amazon@gmail.com</li>
                <li>Mailing address: 256 JUHU Mumbai</li>
            </ul><br><br>
            <button onclick="changeText(this)">Apply Now</button><br><br>
            <script>
                function changeText(id) {
                   id.innerHTML = "Applied";
                   alert("Your application Submitted");
                }
            </script>
        </main>
        <footer>
            <div class="left">
                <h2>Office Address:</h2>
                <p>B-161<br>Ashok Vihar<br>Delhi-110052<p>
            </div>
            <div class="main" style=" width: 30%; float: left">
                <a href="ourteam.php"">Our Team</a><br>
                <a href="aboutus.php">About Us</a><br>
                <a href="privacypolicy.php">Privacy Policy</a><br>
                <a href="termsnconditions.php">Terms and Conditions</a>
            </div>
            <div class="right">
                <h2>Contact Us:</h2>
                <p>+91 8826033672<br>+91 7718025123<br>+91 9869799006</p>
            </div>
        </footer>
    </body>
</html>