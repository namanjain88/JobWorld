<html>
    <head>
        <title>All Jobs</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="homepage.css">
        <script language="javascript" src="home.js"></script>
        <link rel="icon" href="favicon.png" type="image/x-icon"/>
        <script>
        function myFunction3() {
  document.getElementById("myDropdown3").classList.toggle("show3");
}

window.onclick = function(event) {
  if (!event.target.matches('.dropbtn3')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show3')) {
        openDropdown.classList.remove('show3');
      }
    }
  }
}</script>
    <style>
        form input{
            margin-left: 30%;
            margin-top: 10px;
            width: 30%;
            height: 30px;
            border: solid;
            
        }
   
        </style>
    </head>
    <body>
        <nav id="nav">
        <ul>
            <li><i>JOBWORLD</i></li>
            <li><a href="homepage.php">HOME</a></li>
            <li><button onclick="myFunction()" class="dropbtn">JOBS</button> </li>
                <div id="myDropdown" class="dropdown-content">
                    <a href="alljobs.php">All Jobs</a>
                     <a href="jobsbycity.php">Jobs By City</a>
                     <a href="jobsbydomain.php">Jobs By Domain</a>
                </div>
           
             <li><button onclick="myFunction2()" class="dropbtn2">INTERNSHIPS</button> </li>
            <div id="myDropdown2" class="dropdown-content">
                <a href="allinternships.php">All Internships</a>
                     <a href="internshipbycity.php">Internships By City</a>
                     <a href="internshipbydomain.php">Internships By Domain</a>
                </div>
              
             <li><button onclick="myFunction3()" class="dropbtn3">POST</button></li>     
            <div id="myDropdown3" class="dropdown-content">
                <a href="jobpost.php">Post a Job</a>
                     <a href="PostInternship.php">Post an Internship</a>
                    
                </div>
             <li><a href="resumetemplates.php" class="favourites">RESUME</a></li>
             <li><a href="aboutus.php">ABOUT US</a></li>
             <li style="margin-left: 30%;"><a href="myprofile.php">MY PROFILE</a></li>
        </ul>
        </nav>
        
        <form>
            <input type="search" name="search" placeholder="Search" id="searchbar">
        </form>
        <script>
            var search_input=document.querySelector("#searchbar");
            search_input.addEventListener("keyup",function(e){
                console.log(e.target.value)
                var search_item=e.target.value;
                var span_items=document.querySelectorAll(".job")
                span_items.forEach(function(job){
                    if(job.textContent.indexOf(search_item)!=-1){
                        job.closest(".job").style.display="block";
                    }
                    else{
                         job.closest(".job").style.display="none";
                    }
                })
            })
        </script>
       
        
        <div class="job" style="margin-top: 50px;"> 
                <img src="amazon.png" alt="amazon">
                <h2>AMAZON<br>(Web Development)</h2><br><br>
                  
                <ul>
                    <li>Start Date: 5 January 2022</li>
                    <li>Salary: 12LPA</li>   
                    <li>Work Experience: 2 years</li>
                    <li>Location: Chennai</li>
                </ul>
                <button onclick="location.href='amazonWD.php'">Know More</button>
               
        </div>
         <div class="job"> 
             <img src="flipkart.png" alt="flipkart">
                <h2>FLIPKART<br>(Data Analysis)</h2><br><br>
                <ul>
                    <li>Start Date: 20 November 2021</li>
                    <li>Salary: 15LPA</li>
                    <li>Work Experience: 5 year</li>
                    <li>Location: Mumbai</li>
                </ul>
                <button>Know More</button>
        </div>
                </div>
             <div class="job"> 
                 <img src="infosys.png" alt="Infosys">
                <h2>Infosys<br>(Software Development)</h2><br><br>
                <ul>
                    <li>Start Date: 2 December2021</li>
                    <li>Salary: 12LPA</li>
                    <li>Work Experience: 1.5 year</li>
                    <li>Location: Mumbai</li>
                </ul>
                <button>Know More</button>
        </div>
         <div class="job"> 
             <img src="tcs.png" alt="TCS">
                <h2>Tata Consultancy Services<br>(Software Development)</h2><br><br>
                <ul>
                    <li>Start Date: 15 October 2021</li>
                    <li>Salary: 11 LPA</li>
                    <li>Work Experience: 6 months</li>
                    <li>Location: Bangalore</li>
                </ul>
                <button>Know More</button>
        </div>
        
         <div class="job"> 
             <img src="hcl.png" alt="HCL">
                <h2>Hindustan Computers Limited<br>(Web Development)</h2><br><br>
                <ul>
                    <li>Start Date: 2 October 2021</li>
                    <li>Salary: 10 LPA</li>
                    <li>Work Experience: 6 months</li>
                    <li>Location: Hyderabad </li>
                </ul>
                <button>Know More</button>
        </div>
         <div class="job"> 
             <img src="wipro.png" alt="Wipro">
                <h2>Wipro<br>(Data Analysis)</h2><br><br>
                <ul>
                    <li>Start Date: 15 November 2021</li>
                    <li>Salary: 9 LPA</li>
                    <li>Work Experience: 1 year</li>
                    <li>Location: Mumbai</li>
                </ul>
                <button>Know More</button>
        </div>
         <div class="job"> 
             <img src="accenture.png" alt="Accenture">
                <h2>Accenture<br>(Data Analysis)</h2><br><br>
                <ul>
                    <li>Start Date:17 October 2021</li>
                    <li>Salary: 11.5LPA</li>
                    <li>Work Experience: 1 year</li>
                    <li>Location: Delhi</li>
                </ul>
                <button>Know More</button>
        </div>
        </div>
         <div class="job"> 
             <img src="paytm.png" alt="Paytm">
                <h2>Paytm <br>(Data Analysis)</h2><br><br>
                <ul>
                    <li>Start Date: 20 November 2021</li>
                    <li>Salary: 15LPA</li>
                    <li>Work Experience: 1 year</li>
                    <li>Location: Mumbai</li>
                </ul>
                <button>Know More</button>
        </div>
        </div>
         <div class="job"> 
             <img src="google.png" alt="Google">
                <h2>Google<br>(Data Analysis)</h2><br><br>
                <ul>
                    <li>Start Date: 16 November 2021</li>
                    <li>Salary: 12.5LPA</li>
                    <li>Work Experience: 1 year</li>
                    <li>Location: Mumbai</li>
                </ul>
                <button>Know More</button>
        </div>
        </div>
         <div class="job"> 
             <img src="microsoft.png" alt="Microsoft">
                <h2>Microsoft<br>(Senior Data Manager)</h2><br><br>
                <ul>
                    <li>Start Date: 3 January 2022</li>
                    <li>Salary: 12 LPA</li>
                    <li>Work Experience: 1 year</li>
                    <li>Location: Bangalore</li>
                </ul>
                <button>Know More</button>
        </div>
        <div class="job"> 
            <img src="IBM.png" alt="IBM ">
                <h2>IBM <br>(Software Developer)</h2><br><br>
                <ul>
                    <li>Start Date: 3 March 2022</li>
                    <li>Salary: 7 LPA</li>
                    <li>Work Experience: 1.5 year</li>
                    <li>Location: Bangalore</li>
                </ul>
                <button>Know More</button>
        </div>
        <div class="job"> 
            <img src="intel.jpg" alt="Intel ">
                <h2>Intel <br>(Marketing)</h2><br><br>
                <ul>
                    <li>Start Date: 2 Feburary 2022</li>
                    <li>Salary: 10 LPA</li>
                    <li>Work Experience: 1 year</li>
                    <li>Location: Hyderabad</li>
                </ul>
                <button>Know More</button>
        </div>
        
        <div class="job"> 
            <img src="nari.jpg" alt="NARI">
                <h2>Nimbkar Agricultural Research Institute<br>(Chemical Engineering)</h2><br><br>
                <ul>
                    <li>Start Date: 5 January 2022</li>
                    <li>Salary: 12LPA</li>
                    <li>Work Experience: 2 years</li>
                    <li>Location: Pune</li>
                </ul>
                <button>Know More</button>
        </div>
         <div class="job"> 
             <img src="kaizen.png" alt="Kaizen">
                <h2>Kaizen Diagnosis Centre<br>(Microbiology)</h2><br><br>
                <ul>
                    <li>Start Date: 20 November 2021</li>
                    <li>Salary: 10LPA</li>
                    <li>Work Experience: 1 year</li>
                    <li>Location: Pune</li>
                </ul>
                <button>Know More</button>
        </div>
        <div class="job"> 
            <img src="technofiz.png" alt="Technofizi">
                <h2>TechnoFizi Solutions<br>(Digital Marketing)</h2><br><br>
                <ul>
                    <li>Start Date: 20 December 2021</li>
                    <li>Salary: 8LPA</li>
                    <li>Work Experience: 1 year</li>
                    <li>Location: Pune</li>
                </ul>
                <button>Know More</button>
        </div>
         <div class="job"> 
            <img src="hanchens.png" alt="Hanchens">
                <h2>Hanchens<br>(Chartered Accountancy (CA))</h2><br><br>
                <ul>
                    <li>Start Date: 5 January 2022</li>
                    <li>Salary: 12LPA</li>
                    <li>Work Experience: 2 years</li>
                    <li>Location: Work From Home</li>
                </ul>
                <button>Know More</button>
        </div>
         <div class="job"> 
             <img src="friskydesigns.jpg" alt="friskydesigns">
                <h2>Frisky Designs<br>(Project Management)</h2><br><br>
                <ul>
                    <li>Start Date: 20 November 2021</li>
                    <li>Salary: 15LPA</li>
                    <li>Work Experience: 1 year</li>
                    <li>Location: Work From Home</li>
                </ul>
                <button>Know More</button>
        </div>
         <div class="job"> 
             <img src="apohancorp.jpg" alt="apohancorporate">
                <h2>Apohan Corporate Consultants Private Limited<br>(Marketing)</h2><br><br>
                <ul>
                    <li>Start Date: 25 December 2021</li>
                    <li>Salary: 5LPA</li>
                    <li>Work Experience: 1 year</li>
                    <li>Location: Work From Home</li>
                </ul>
                <button>Know More</button>
        </div>
        <div class="job"> 
            <img src="atdrive.png" alt="atdrive">
                <h2>AtDrive<br>(Chartered Accountancy (CA))</h2><br><br>
                <ul>
                    <li>Start Date: 5 February 2022</li>
                    <li>Salary: 12LPA</li>
                    <li>Work Experience: 2 years</li>
                    <li>Location: Kolkata</li>
                </ul>
                <button>Know More</button>
        </div>
         <div class="job"> 
             <img src="internshala.jpg" alt="internshala">
                <h2>INTERNSHALA<br>(Marketing)</h2><br><br>
                <ul>
                    <li>Start Date: 20 November 2021</li>
                    <li>Salary: 15LPA</li>
                    <li>Work Experience: 1 year</li>
                    <li>Location: Kolkata</li>
                </ul>
                <button>Know More</button>
        </div>
        <div class="job"> 
            <img src="webberhelp.png" alt="webberhelp">
                <h2>Whelp Services Private Limited<br>(Digital Marketing)</h2><br><br>
                <ul>
                    <li>Start Date: 22 December 2021</li>
                    <li>Salary: 8LPA</li>
                    <li>Work Experience: 0 years</li>
                    <li>Location: Kolkata</li>
                </ul>
                <button>Know More</button>
        </div>
        <div class="job"> 
            <img src="womenhopes.png" alt="womenhopes">
                <h2>Women Hopes<br>(Pharmaceutical)</h2><br><br>
                <ul>
                    <li>Start Date: 3 December 2021</li>
                    <li>Salary: 5LPA</li>
                    <li>Work Experience: 1+ year</li>
                    <li>Location: Kolkata</li>
                </ul>
                <button>Know More</button>
        </div>
        <div class="job"> 
            <img src="hakuna matata.jpg" alt="hakunamatata">
                <h2>Hakuna Matata Food Forest<br>(Hotel Management)</h2><br><br>
                <ul>
                    <li>Start Date: 13 November 2021</li>
                    <li>Salary: 11LPA</li>
                    <li>Work Experience: 2+ years</li>
                    <li>Location: Kolkata</li>
                </ul>
                <button>Know More</button>
        </div>
        
         <div class="job"> 
            <img src="housy.png" alt="Housy">
                <h2>Housy<br>(Finance)</h2><br><br>
                <ul>
                    <li>Start Date: 12 January 2022</li>
                    <li>Salary: 8.5LPA</li>
                    <li>Work Experience: 3+ year</li>
                    <li>Location: Hyderabad</li>
                </ul>
                <button>Know More</button>
        </div>
        <div class="job"> 
            <img src="trikolatech.png" alt="TrikolaTech">
                <h2>Trikolaa Tech<br>(3D Printing)</h2><br><br>
                <ul>
                    <li>Start Date: 22 January 2022</li>
                    <li>Salary: 5LPA</li>
                    <li>Work Experience: 5 year</li>
                    <li>Location: Hyderabad</li>
                </ul>
                <button>Know More</button>
        </div>
        <div class="job"> 
            <img src="pepodeal.jpg" alt="PepoDeal">
                <h2>Jetic Healthcare Private Limited (Pepodeal)<br>(Biomedical Engineering)</h2><br><br>
                <ul>
                    <li>Start Date: 18 March 2022</li>
                    <li>Salary: 4.5LPA</li>
                    <li>Work Experience: 0 year</li>
                    <li>Location: Hyderabad</li>
                </ul>
                <button>Know More</button>
        </div>
         <div class="job"> 
            <img src="pace360.png" alt="Pace360">
                <h2>Pace 360<br>(Social Media Marketing)</h2><br><br>
                <ul>
                    <li>Start Date:13 December 2021</li>
                    <li>Salary: 5LPA</li>
                    <li>Work Experience: 0 year</li>
                    <li>Location: Delhi</li>
                </ul>
                <button>Know More</button>
        </div>
        <div class="job"> 
            <img src="medbound.jpg" alt="medbound">
                <h2>MedBound<br>(Medical Content Contribution)</h2><br><br>
                <ul>
                    <li>Start Date:5 December 2021</li>
                    <li>Salary: 7LPA</li>
                    <li>Work Experience: 2 years</li>
                    <li>Location: Delhi</li>
                </ul>
                <button>Know More</button>
        </div>
        <div class="job"> 
            <img src="functionjunction.jpg" alt="functionjunction">
                <h2>Function Junction<br>(Event Management)</h2><br><br>
                <ul>
                    <li>Start Date:5 November 2021</li>
                    <li>Salary: 12LPA</li>
                    <li>Work Experience: 2 years</li>
                    <li>Location: Delhi</li>
                </ul>
                <button>Know More</button>
        </div>
           <div class="job" style="margin-top: 50px;"> 
            <img src="AIPL.png" alt="AIPL">
                <h2>Accord Innovations Private Limited<br>(Biomedical)</h2><br><br>
                  
                <ul>
                    <li>Start Date: 25 January 2022</li>
                    <li>Salary: 7LPA</li>   
                    <li>Work Experience: 0 years</li>
                    <li>Location: Chennai</li>
                </ul>
                <button onclick="location.href='amazonWD.php'">Know More</button>           
        </div>
        <div class="job" style="margin-top: 50px;"> 
            <img src="bob.png" alt="BOB">
                <h2>Bank Of Baroda<br>(Branch Manager)</h2><br><br>
                  
                <ul>
                    <li>Start Date: 8 December 2021</li>
                    <li>Salary: 18LPA</li>   
                    <li>Work Experience: 5+ years</li>
                    <li>Location: Chennai</li>
                </ul>
                <button onclick="location.href='amazonWD.php'">Know More</button>           
        </div>
        <div class="job" style="margin-top: 50px;"> 
            <img src="britannia.png" alt="Britannia">
                <h2>Britannia<br>(Marketing Executive)</h2><br><br>
                  
                <ul>
                    <li>Start Date: 18 December 2021</li>
                    <li>Salary: 8LPA</li>   
                    <li>Work Experience: 2+ years</li>
                    <li>Location: Chennai</li>
                </ul>
                <button onclick="location.href='amazonWD.php'">Know More</button>           
        </div>
        <div class="job" style="margin-top: 50px;"> 
            <img src="carpm.png" alt="CaRPM">
                <h2>CaRPM<br>(Automotive Research)</h2><br><br>
                  
                <ul>
                    <li>Start Date: 23 November 2021</li>
                    <li>Salary: 4.5LPA</li>   
                    <li>Work Experience: 0 years</li>
                    <li>Location: Chennai</li>
                </ul>
                <button onclick="location.href='amazonWD.php'">Know More</button>           
        </div>
         <div class="job"> 
            <img src="arinjayacademy.jpg" alt="arinjay academy">
                <h2>Arinjay Academy<br>(Digital Marketing)</h2><br><br>
                <ul>
                    <li>Start Date: 5 January 2022</li>
                    <li>Salary: 4LPA</li>
                    <li>Work Experience: 0-2 years</li>
                    <li>Location: Bangalore</li>
                </ul>
                <button>Know More</button>
        </div>
         <div class="job"> 
             <img src="championlearns.png" alt="championlearns">
                <h2>Champion Learns<br>(Marketing)</h2><br><br>
                <ul>
                    <li>Start Date: 20 November 2021</li>
                    <li>Salary: 5LPA</li>
                    <li>Work Experience: 1 year</li>
                    <li>Location: Bangalore</li>
                </ul>
                <button>Know More</button>
        </div>
        <div class="job"> 
            <img src="icicibank.png" alt="icicibank">
                <h2>ICICI Bank<br>(Finance)</h2><br><br>
                <ul>
                    <li>Start Date: 13 January 2021</li>
                    <li>Salary: 15LPA</li>
                    <li>Work Experience: 1 year</li>
                    <li>Location: Bangalore</li>
                </ul>
                <button>Know More</button>
        </div>
        
        
        <a href="#nav" style="margin-left: 40%; font-size: 20px; color: blue;">Click Here To Go At Top</a>
        
        <footer>
            <div class="left">
                <h2>Office Address:</h2>
                <p>B-161<br>Ashok Vihar<br>Delhi-110052<p>
            </div>
            <div class="main" style=" width: 30%; float: left">
                <a href="ourteam.php"">Our Team</a><br>
                <a href="aboutus.php">About Us</a><br>
                <a href="privacypolicy.php">Privacy Policy</a><br>
                <a href="termsnconditions.php">Terms and Conditions</a>
            </div>
            <div class="right">
                <h2>Contact Us:</h2>
                <p>+91 8826033672<br>+91 7718025123<br>+91 9869799006</p>
            </div>
        </footer>

    </body>
</html>
