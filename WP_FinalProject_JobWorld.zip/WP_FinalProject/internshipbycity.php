<html>
    <head>
        <title>Internships By City</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="jobsbycity.css">
        <script language="javascript" src="home.js"></script>
        <link rel="icon" href="favicon.png" type="image/x-icon"/>
                <script>
        function myFunction3() {
  document.getElementById("myDropdown3").classList.toggle("show3");
}

window.onclick = function(event) {
  if (!event.target.matches('.dropbtn3')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show3')) {
        openDropdown.classList.remove('show3');
      }
    }
  }
}</script>
    </head>
    <body>
        <nav>
        <ul>
            <li><i>JOBWORLD</i></li>
            <li><a href="homepage.php">HOME</a></li>
            <li><button onclick="myFunction()" class="dropbtn">JOBS</button> </li>
                <div id="myDropdown" class="dropdown-content">
                    <a href="alljobs.php">All Jobs</a>
                     <a href="jobsbycity.php">Jobs By City</a>
                     <a href="jobsbydomain.php">Jobs By Domain</a>
                </div>
           
             <li><button onclick="myFunction2()" class="dropbtn2">INTERNSHIPS</button> </li>
            <div id="myDropdown2" class="dropdown-content">
                <a href="allinternships.php">All Internships</a>
                     <a href="internshipbycity.php">Internships By City</a>
                     <a href="internshipbydomain.php">Internships By Domain</a>
                </div>
             <li><button onclick="myFunction3()" class="dropbtn3">POST</button></li>     
            <div id="myDropdown3" class="dropdown-content">
                <a href="jobpost.php">Post a Job</a>
                     <a href="PostInternship.php">Post an Internship</a>
                    
                </div>
             <li><a href="resumetemplates.php">RESUME</a></li>
            <li><a href="aboutus.php">ABOUT US</a></li>
            <li style="margin-left: 30%;"><a href="myprofile.php">MY PROFILE</a></li>
        </ul>
        </nav>
        <header>
            <h1>Internships By City</h1>
        </header>
        <main>
            <div class="left">
                <a href="delhiinternships.php"><img src="intdelhi.jpeg" alt="delhi"></a>
            </div>
            <div class="right">
                <a href="mumbaiinternships.php"><img src="intmumbai.jpeg" alt="mumbai"></a>
            </div>
            <div class="left">
                <a href="chennaiinternships.php"><img src="intchennai.jpeg" alt="chennai"></a>
            </div>
            <div class="right">
                <a href="bangaloreinternships.php"><img src="intbanglore.jpeg" alt="banglore"></a>
            </div>
            <div class="left">
                <a href="kolkatainternships.php"><img src="intkolkata.jpeg" alt="kolkata"></a>
            </div>
            <div class="right">
                <a href="puneinternships.php"><img src="intpune.jpeg" alt="pune"></a>
            </div>
            <div class="left">
                <a href="hyderabadinternships.php"><img src="inthyderabad.jpeg" alt="hyderabad"></a>
            </div>
            <div class="right">
                <a href="wfhinternships.php"><img src="wfhinternships1.jpg" alt="work from home"></a>
            </div>
        </main>
        
    </body>
</html>


