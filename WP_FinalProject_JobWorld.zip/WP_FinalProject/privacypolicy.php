<!DOCTYPE html>
<html lang="en-us">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title> Privacy Policy </title>
        <script language="javascript" src="home.js"></script>
        <link rel="icon" href="favicon.png" type="image/x-icon"/>
        <script>
        function myFunction3() {
  document.getElementById("myDropdown3").classList.toggle("show3");
}

window.onclick = function(event) {
  if (!event.target.matches('.dropbtn3')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show3')) {
        openDropdown.classList.remove('show3');
      }
    }
  }
}</script>
</head>
<style>

nav li{
    float: left;
    color: white;
    display: block;
}
nav ul{
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color:blue;
}
nav li a{
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}
nav li a:hover{
  background-color:lightblue;
  color: blue;
}
nav i{
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

.dropdown-content {
  display: none;
  position: absolute;
  top: 50px;
  left: 200px;
  background-color: lightblue;
  min-width: 200px;
  overflow: auto;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
}

.dropdown-content a {
  color: blue;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {
    background-color: blue;
    color: white;
}

.show,.show2,.show3 {display: block;}

.dropbtn,.dropbtn2,.dropbtn3{
    color: white;
    background-color: blue;
    border: none;
    padding: 14px 16px;
    height: 45px;
}
.dropbtn:hover,.dropbtn2:hover,.dropbtn3:hover{
    background-color: lightblue;
    color: blue;
}

.dropdown-content2 {
  display: none;
  position: absolute;
  top: 50px;
  left: 200px;
  background-color: lightblue;
  min-width: 160px;
  overflow: auto;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
}

.dropdown-content2 a {
  color: blue;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content2 a:hover {
    background-color: blue;
    color: white;
}
.dropdown-content3 {
  display: none;
  position: absolute;
  top: 50px;
  left: 500px;
  background-color: lightblue;
  min-width: 160px;
  overflow: auto;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
}

.dropdown-content3 a {
  color: blue;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content3 a:hover {
    background-color: blue;
    color: white;
}
main{
    background-color: lightcyan;
    margin-left: 5%;
    margin-right: 5%;
    padding: 10px;
    font-size: 110%;
}
.heading span{
    background-color: lightblue;
    color: blue;
    width: 10px;
}
footer{
    background-color: black;
    height: 230px;
    margin-top: 20px;
}
footer .left{
    float: left;
    margin-left: 10%;
    width: 30%;
    color: white;
    margin-top: 20px;
}
footer .main a{
  
    text-decoration: none;
    color: white;
    font-size: 20px;
}
footer .main a:hover{
    color: blue;
}
footer .main{
    margin-top: 40px;
      float: left;
}
footer .right{
    float: left;
    color: white;
     margin-top: 20px;

</style>
<body>
    <nav id="nav">
        <ul>
            <li><i>JOBWORLD</i></li>
            <li><a href="homepage.php">HOME</a></li>
            <li><button onclick="myFunction()" class="dropbtn">JOBS</button> </li>
                <div id="myDropdown" class="dropdown-content">
                    <a href="alljobs.php">All Jobs</a>
                     <a href="jobsbycity.php">Jobs By City</a>
                     <a href="jobsbydomain.php">Jobs By Domain</a>
                </div>
           
             <li><button onclick="myFunction2()" class="dropbtn2">INTERNSHIPS</button> </li>
            <div id="myDropdown2" class="dropdown-content">
                <a href="allinternships.php">All Internships</a>
                     <a href="internshipbycity.php">Internships By City</a>
                     <a href="internshipbydomain.php">Internships By Domain</a>
                </div>
              
             <li><button onclick="myFunction3()" class="dropbtn3">POST</button></li>     
            <div id="myDropdown3" class="dropdown-content">
                <a href="jobpost.php">Post a Job</a>
                     <a href="PostInternship.php">Post an Internship</a>
                    
                </div>
             <li><a href="resumetemplates.php">RESUME</a></li>
             <li><a href="aboutus.php">ABOUT US</a></li>
             <li style="margin-left: 30%;"><a href="myprofile.php">MY PROFILE</a></li>
        </ul>
        </nav>
  <h1 class="heading" style="text-align: center;">
        <span>J</span>
        <span>O</span>
        <span>B</span>
        <span>W</span>
        <span>O</span>
        <span>R</span>
        <span>L</span>
        <span>D</span>
    </h1>
    
<h2 style='text-align:center; color: blue; font-size: 30px; font-family: cursive;'>Privacy Policy</h2>
<main>
<p>This Privacy Policy applies to the online services offered by Jobworld at jobworld.com, its subdomains and Jobworld’s app on Google Play Store. These are henceforth collectively known as Services.This policy applies to those who visit the Platform, or whose information Jobworld otherwise receives in connection with its services (such as contact information of individuals associated with Services including partners) (hereinafter collectively referred to as "Users"). For the purposes of the Privacy Policy, "You" or "Your" shall mean the person who is accessing the Platform.</p>
<br>
<h3>Overview</h3>
<p>We respect your privacy and strive to provide a safe, secure user experience. This privacy statement sets forth our online data collection and usage policies and practices. By using our services, you consent to the policies and practices described in this statement. Your data will be stored and processed on our servers which may be inside or outside India and your usage of the Services constitutes consent to the transfer of your data out of India. Our Services may contain links to other website over which we have no control and we are not responsible for the privacy policies or practices of other websites to which you navigate from our Services. We encourage you to review the privacy policies of these other websites so you can understand how they collect, use and share your information. This privacy statement applies solely to the information we collect on jobworld.com and its sub-domains and not to information collected otherwise.</p>
<br>
<h3>Collection of Information</h3>
<p><b>Personal information provided by you:</b><br>In some areas of our Services, we request you to provide or submit personal information including your name, address, email address, telephone number, contact information, billing information, education details, work place details, and any other information from which your identity is discernible. Jobworld also collects or may collect demographic information that is not unique to you such as your ZIP code, age, preferences and gender. Example of such a situation could include, but is not limited to when you sign up to use our service, post a resume or enter a contest or survey.<br><br>
<b>Information collected when you use third party services:</b><br>
For a better experience, and in order to provide our service, we may require you to provide us, either directly or indirectly, with certain personally identifiable information, including but not limited to user name. The information that we request will be retained by us and used as described in this privacy policy.
Jobworld uses third-party services that may collect information used to identify you. Find below a list of services used, and the privacy policies of these services:
<ul><li><a href='https://policies.google.com/privacy' target='_blank'>Google Sign-In privacy policy</a></li><li><a href='https://www.youtube.com/t/terms' target='_blank'>YouTube privacy policy</a></li><li><a href='https://www.facebook.com/policy.php' target='_blank'>Facebook privacy policy</a></li></ul><br>
We may collect, process and store your information associated with your Google account if you choose to sign in using Google. When you sign in to your account with your Google account information, you consent to our collection, storage, and use of the information that you make available to us through your Google account in accordance with this Privacy Policy. This could include your name, email address and phone number associated with your Google account. If you are registering as an employer and choose to authenticate your company using social media, then with your explicit consent to our data collection, we will collect your page name and count of followers as available to us through your Google or Facebook or Instagram account. We also use Youtube API services to collect your channel name and count of subscribers for account verification purposes. This data will be collected, processed and stored in accordance with this Privacy Policy.<br><br>
<b>Information about your contacts:</b><br>When you choose to share content on Jobworld with friends using the Google+ share feature and sign in using your Google account, we may collect, process and store information of the contacts (email addresses of contacts) associated with your Google account. Also, when you share content with your friends through SMS share option on Jobworld, we may collect, process and store information of the contacts (phone numbers) to whom you choose to send the SMS.<br><br>
<b>Information collected through use of service:</b><br>We also gather or may gather certain information about your use of our Services, such as what areas you visit and what features you access. Moreover, there is information about your computer hardware and software that is or may be collected by us. This information can include without limitation your IP address, browser type, domain names, access times and referring website addresses and can be used by Jobworld as it deems fit. If you message applicants through the Jobworld chat platform, we also collect and may access your chat history.
</p>
<br>
<h3>Retention of Information</h3>
<p>Since we believe that managing your career is a life-long process, we retain indefinitely all the information we gather about you in an effort to make your repeat use with us more efficient, practical, and relevant. You can correct or update your account profile and resume at any time. You may choose to delete your account, following which we will either delete or de-identify the data.</p>
<br>
<h3>Sharing of Information</h3>
<p>
<ul>
<li>If you are an employer, information related to your internship and/or job post such as organisation name, URL, and description, job description, skills required etc. is published online and can be viewed by anyone visiting Jobworld site and app. This information may also appear in search websites like Google. Further, we may share your personal information (including contact details) with students who apply to your internships and/or jobs or get hired by you through Jobworld.</li>
<li>If you are an applicant, we may share your personal information with employers whose internships and/or jobs you apply to or whose internships and/or jobs we feel may be relevant for you or who may come across your profile through a search of our user base.</li>
<li>We may share your information with third party individuals, contractors, companies and other service providers that perform services on our behalf or in partnership with us. For example, we may require to pass on your data to a partner who might be responsible for the delivery of a training program that you may have voluntarily signed up for.</li>
<li>Additionally, you may have the option to share your information and activities on Jobworld through social media. We do not have control over information shared with third party social networks and you should review the policies of those networks before consenting to share information with them.</li>
<li>If you post any of your personal information in public areas of Jobworld, such as in online forums, chat rooms, comments section etc. this information will be accessible to everyone on the public internet. It may be collected and used by others over whom Jobworld has no control. We are not responsible for the use made by third parties of information you post or otherwise make available in public areas of this website.</li>
<li>When we send you an email or SMS, we use a third party service. In this case, it becomes necessary to pass on your email address/ mobile number to the third party. While we only work with reputed service providers in this regard, we are not responsible for the use made by them of this information.</li>
<li>Jobworld reserves the right to publish the internship and/or job post of companies on social media platforms and 3rd party websites like LinkedIn, Indeed, Sheroes, Qween, etc.along with newspapers and magazines, in order to increase the visibility of the post.</li>
<li>We may also share your information in order to investigate, prevent, or take action about possible illegal activities or to comply with legal process. We may also share your information with third parties to investigate and address violations of this Privacy Policy or the Terms of Service, or to investigate and address violations of the rights of third parties and/or Jobworld, our employees, users, or the public. This may involve the sharing of your information with law enforcement, government agencies, courts, and/or other organizations.</li>
</ul>
</p>
<br>
<h3>Editing Information</h3>
<p>If you are a student, you may edit your personal information and profile by visiting your resume section. Certain data (such as applications you may have made) cannot be edited.
If you are an employer, you may edit your personal information and information about your organization by visiting the profile (personal details and organization details) section. Certain data (such as internships you may post, applications you may have processed) cannot be edited.</p>
<br>
<h3>Downloading Information</h3>
<p>Our customer support team will be happy to help you with this. Please write to us at <a href="mailto:privacy@jobworld.com">privacy@jobworld.com.</a></p>
<br>
<h3>Communication Policy</h3>
<p><b>For opt-in</b><br>
For a user to receive our weekly newsletter, student/employer digests and/or any other marketing communication from us over email; Jobworld follows a double opt-in policy where after submitting your email address you need to verify it by clicking on a verification link that we would send to you over given email address. Until the email is verified, you would not receive the newsletter or any marketing communication from us.<br><b>For opt-out</b><br>Marketing/ Digests/ Newsletter: Every newsletter and promotional communication from Jobworld contains an 'Unsubscribe' link that you can click on to stop receiving any future newsletters and promotional content from us on your email. It may take upto 7 days for your unsubscription request to be processed.
Transactional: We require to send users transactional communication as this is required for proper functioning of our service. If you wish to discontinue receiving any transactional communication from Jobworld, write to us at <a href="mailto:privacy@jobworld.com">privacy@jobworld.com.</a></p>
<br>
<h3>Cookies and pixel tags</h3><p>We and third parties with whom we partner, may use cookies, web beacons, pixel tags etc. to collect information regarding your use of Jobworld and third party websites. A cookie is a small text file that is stored on your computer that enables us to remember you (for example, as a registered user) and your actions when you visit our website. This helps us remember your preferences and searches, improve your experience (for example, by keeping you logged in), customize content according to your preferences and perform analytics, and assist with security and administrative functions. Cookies may be persistent or stored only during an individual session ,as necessary. A pixel tag is a tiny graphic with a unique identifier embedded invisibly in an email and may be used to track whether the email has been opened and for other analytics.<br>Most modern browsers will allow you to disable some/all cookies for any website. However, this is not recommended and doing so may interfere with normal functioning of Jobworld. If you do not turn cookies off, please make sure you logout when you finish using a shared computer.</p>
<br>
<h3>Children</h3><p>Jobworld is not intended for children under 13 years of age. If you are less than 13 years old at the time of your first visit to Jobworld, you are prohibited from using the website further entirely on your own. You may do so under parental guidance. However, please note that we have no way of determining your age when you visit our website or whether you have parental supervision available or not. We do not intend to and do not knowingly collect personal information from children under 13. However, since we do not collect information on a user's birth date and proof of same, there is no foolproof way for us to ensure the same.</p>
<br>
<h3>Security of Information</h3><p>We have implemented generally accepted industry standards in terms of security measures to protect your information on Jobworld. The third party payment service providers (payment gateways) are all validated as compliant with the payment card industry standard (generally referred to as PCI compliant service providers).
While we try our best to safeguard information, there may be factors beyond our control that may result in unwanted disclosure of information. We assume no liability or responsibility for disclosure of your information due to causes beyond our control.
In order to keep personal information secure, you must not share your password or other security information (for example, unique keys) of your Jobworld account with anyone. If you are using a shared computer, please make sure you logout after every use. If we receive instructions using your email and password, we will consider that the instructions have been authorized by you.
</p>
<br>
<h3>No Guarantees</h3><p>While this Privacy Policy states our standards for maintenance of data and we will make efforts to meet them, we are not in a position to guarantee these standards. There may be factors beyond our control that may result in disclosure of data. As a consequence, we disclaim any warranties or representations relating to maintenance or nondisclosure of data.</p>
<br>
<h3>Changes to this Privacy Policy</h3><p>We may make changes to this Policy from time to time. We may notify you of substantial changes to this Policy either by posting a prominent announcement on our Services and/or by sending a message to the e-mail address you have provided to us. You are advised to refer to this page to know about our latest Privacy Policy.</p>
</main>
<footer>
            <div class="left">
                <h2>Office Address:</h2>
                <p>B-161<br>Ashok Vihar<br>Delhi-110052<p>
            </div>
            <div class="main" style=" width: 30%; float: left">
                <a href="ourteam.php"">Our Team</a><br>
                <a href="aboutus.php">About Us</a><br>
                <a href="privacypolicy.php">Privacy Policy</a><br>
                <a href="termsnconditions.php">Terms and Conditions</a>
            </div>
            <div class="right">
                <h2>Contact Us:</h2>
                <p>+91 8826033672<br>+91 7718025123<br>+91 9869799006</p>
            </div>
        </footer>
</body>
</html>
