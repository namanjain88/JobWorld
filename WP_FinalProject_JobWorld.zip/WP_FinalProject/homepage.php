
<html>
    <head>
        <title>JobWorld-Home</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="homepage.css">
        <script language="javascript" src="home.js"></script>
        <link rel="icon" href="favicon.png" type="image/x-icon"/>
        <script>
        function myFunction3() {
  document.getElementById("myDropdown3").classList.toggle("show3");
}

window.onclick = function(event) {
  if (!event.target.matches('.dropbtn3')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show3')) {
        openDropdown.classList.remove('show3');
      }
    }
  }
}</script>
    </head>
    <body>
        <nav id="nav">
        <ul>
            <li><i>JOBWORLD</i></li>
            <li><a href="homepage.php">HOME</a></li>
            <li><button onclick="myFunction()" class="dropbtn">JOBS</button> </li>
                <div id="myDropdown" class="dropdown-content">
                    <a href="alljobs.php">All Jobs</a>
                     <a href="jobsbycity.php">Jobs By City</a>
                     <a href="jobsbydomain.php">Jobs By Domain</a>
                </div>
           
             <li><button onclick="myFunction2()" class="dropbtn2">INTERNSHIPS</button> </li>
            <div id="myDropdown2" class="dropdown-content">
                <a href="allinternships.php">All Internships</a>
                     <a href="internshipbycity.php">Internships By City</a>
                     <a href="internshipbydomain.php">Internships By Domain</a>
                </div>
              
             <li><button onclick="myFunction3()" class="dropbtn3">POST</button></li>     
            <div id="myDropdown3" class="dropdown-content">
                <a href="jobpost.php">Post a Job</a>
                     <a href="PostInternship.php">Post an Internship</a>
                    
                </div>
             <li><a href="resumetemplates.php" class="favourites">RESUME</a></li>
             <li><a href="aboutus.php">ABOUT US</a></li>
             <li style="margin-left: 30%;"><a href="myprofile.php">MY PROFILE</a></li>
        </ul>
        </nav>
        
        <header>
            <img src="jobheader2.jpeg" alt="jobheader">
        </header>
        
        <main>
            <h1 style="text-align: center; font-family: cursive; color: blue; margin-top: 50px; font-size: 50px;">Upcoming Events</h1>
            <table border="1">
                <tr>
                    <th>S.NO</th>
                    <th>Event Name</th>
                    <th>Conducted By</th>
                    <th>Date</th>
                </tr>
                <tr>
                    <td>1</td>
                    <td>Web Development Workshop</td>
                    <td rowspan="2">IBM</td>
                    <td>30 October 2021</td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>Data Analysis Webinar</td>
                    <td>5 November 2021</td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>Marketing Strategies</td>
                    <td>Interactive Avenues Pvt Ltd</td>
                    <td>8 November 2021</td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>Workshop on Future Trends</td>
                    <td>Coursera</td>
                    <td>15 November 2021</td>
                </tr>
            </table>
        </main>
        
         <h1 style="text-align: center; font-family: cursive; color: blue; margin-top: 50px; font-size: 50px;">Top Recruiters</h1>
         <div class="toprecruiters">
             <img src="amazon.png" alt="amazon" style="margin-left: 35%;">
             <img src="flipkart.png" alt="flipkart">
             <img src="accenture.png" alt="accenture">
             <img src="microsoft.png" alt="microsoft">
             <img src="google.png" alt="google">
         </div>
         
         <div class="interview">
              <h1 style="text-align: center; font-family: cursive; color: blue; margin-top: 50px; font-size: 40px;">Interview Preparation</h1>
            <iframe height="400" width="32%" src="https://www.youtube.com/embed/1mHjMNZZvFo"></iframe>
            <iframe height="400" width="32%" src="https://www.youtube.com/embed/TwZ7LgrPwR0"></iframe>
            <iframe height="400" width="32%" src="https://www.youtube.com/embed/gnqzM6FWgTE"></iframe>
         </div>
        
        <h1 style="text-align: center; font-family: cursive; color: blue; margin-top: 50px; font-size: 50px;">Jobs In Demand</h1>
        <div class="job"> 
                <img src="amazon.png" alt="amazon">
                <h2>AMAZON<br>(Web Development)</h2><br><br>
                  
                <ul>
                    <li>Start Date: 5 January 2022</li>
                    <li>Salary: 12LPA</li>   
                    <li>Work Experience: 2 years</li>
                    <li>Location: Chennai</li>
                </ul>
                <button onclick="location.href='amazonWD.php'">Know More</button>
               
        </div>
         <div class="job"> 
             <img src="flipkart.png" alt="flipkart">
                <h2>FLIPKART<br>(Data Analysis)</h2><br><br>
                <ul>
                    <li>Start Date: 20 November 2021</li>
                    <li>Salary: 15LPA</li>
                    <li>Work Experience: 5 year</li>
                    <li>Location: Mumbai</li>
                </ul>
                <button>Know More</button>
        </div>
                </div>
             <div class="job"> 
                 <img src="infosys.png" alt="Infosys">
                <h2>Infosys<br>(Software Development)</h2><br><br>
                <ul>
                    <li>Start Date: 2 December2021</li>
                    <li>Salary: 12LPA</li>
                    <li>Work Experience: 1.5 year</li>
                    <li>Location: Mumbai</li>
                </ul>
                <button>Know More</button>
        </div>
         <div class="job"> 
             <img src="tcs.png" alt="TCS">
                <h2>Tata Consultancy Services<br>(software development)</h2><br><br>
                <ul>
                    <li>Start Date: 15 October 2021</li>
                    <li>Salary: 11 LPA</li>
                    <li>Work Experience: 6 months</li>
                    <li>Location: Banglore</li>
                </ul>
                <button>Know More</button>
        </div>
        
         <div class="job"> 
             <img src="hcl.png" alt="HCL">
                <h2>Hindustan Computers Limited<br>(Web Development)</h2><br><br>
                <ul>
                    <li>Start Date: 2 October 2021</li>
                    <li>Salary: 10 LPA</li>
                    <li>Work Experience: 6 months</li>
                    <li>Location: Hyderabad </li>
                </ul>
                <button>Know More</button>
        </div>
         <div class="job"> 
             <img src="wipro.png" alt="Wipro">
                <h2>Wipro<br>(Data Analysis)</h2><br><br>
                <ul>
                    <li>Start Date: 15 November 2021</li>
                    <li>Salary: 9 LPA</li>
                    <li>Work Experience: 1 year</li>
                    <li>Location: Mumbai</li>
                </ul>
                <button>Know More</button>
        </div>
         <div class="job"> 
             <img src="accenture.png" alt="Accenture">
                <h2>Accenture<br>(Data Analysis)</h2><br><br>
                <ul>
                    <li>Start Date:17 October 2021</li>
                    <li>Salary: 11.5LPA</li>
                    <li>Work Experience: 1 year</li>
                    <li>Location: Delhi</li>
                </ul>
                <button>Know More</button>
        </div>
        </div>
         <div class="job"> 
             <img src="paytm.png" alt="Paytm">
                <h2>Paytm <br>(Data Analysis)</h2><br><br>
                <ul>
                    <li>Start Date: 20 November 2021</li>
                    <li>Salary: 15LPA</li>
                    <li>Work Experience: 1 year</li>
                    <li>Location: Mumbai</li>
                </ul>
                <button>Know More</button>
        </div>
        </div>
         <div class="job"> 
             <img src="google.png" alt="Google">
                <h2>Google<br>(Data Analysis)</h2><br><br>
                <ul>
                    <li>Start Date: 16 November 2021</li>
                    <li>Salary: 12.5LPA</li>
                    <li>Work Experience: 1 year</li>
                    <li>Location: Mumbai</li>
                </ul>
                <button>Know More</button>
        </div>
        </div>
         <div class="job"> 
             <img src="microsoft.png" alt="Microsoft">
                <h2>Microsoft<br>(Software Developer)</h2><br><br>
                <ul>
                    <li>Start Date: 3 January 2022</li>
                    <li>Salary: 12 LPA</li>
                    <li>Work Experience: 1 year</li>
                    <li>Location: Banglore</li>
                </ul>
                <button>Know More</button>
        </div>
        <div class="job"> 
            <img src="IBM.png" alt="IBM ">
                <h2>IBM <br>(Software Developer)</h2><br><br>
                <ul>
                    <li>Start Date: 3 March 2022</li>
                    <li>Salary: 7 LPA</li>
                    <li>Work Experience: 1.5 year</li>
                    <li>Location: Banglore</li>
                </ul>
                <button>Know More</button>
        </div>
        <div class="job"> 
            <img src="intel.jpg" alt="Intel ">
                <h2>Intel <br>(Web Developer)</h2><br><br>
                <ul>
                    <li>Start Date: 2 Feburary 2022</li>
                    <li>Salary: 10 LPA</li>
                    <li>Work Experience: 1 year</li>
                    <li>Location: Hyderabad</li>
                </ul>
                <button>Know More</button>
        </div>
        <a href="#nav" class="gotop">Click Here To Go At Top</a>
        
        <footer>
            <div class="left">
                <h2>Office Address:</h2>
                <p>B-161<br>Ashok Vihar<br>Delhi-110052<p>
            </div>
            <div class="main" style=" width: 30%; float: left">
                <a href="ourteam.php"">Our Team</a><br>
                <a href="aboutus.php">About Us</a><br>
                <a href="privacypolicy.php">Privacy Policy</a><br>
                <a href="termsnconditions.php">Terms and Conditions</a>
            </div>
            <div class="right">
                <h2>Contact Us:</h2>
                <p>+91 8826033672<br>+91 7718025123<br>+91 9869799006</p>
            </div>
        </footer>

    </body>
</html>