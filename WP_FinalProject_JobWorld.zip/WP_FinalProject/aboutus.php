<!DOCTYPE html>
<html>
    <head>
        <title>AboutUS</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
         <script language="javascript" src="home.js"></script>
        <link rel="icon" href="favicon.png" type="image/x-icon"/>
        <script>
        function myFunction3() {
  document.getElementById("myDropdown3").classList.toggle("show3");
}

window.onclick = function(event) {
  if (!event.target.matches('.dropbtn3')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show3')) {
        openDropdown.classList.remove('show3');
      }
    }
  }
}</script>
    <style>
        main{
            background-color: lightcyan;
            margin-left: 10%;
            margin-right: 10%;
            padding: 10px;
            font-size: 110%;
        }
   
            
        
nav li{
    float: left;
    color: white;
    display: block;
}
nav ul{
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color:blue;
}
nav li a{
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}
nav li a:hover{
  background-color:lightblue;
  color: blue;
}
nav i{
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

.dropdown-content {
  display: none;
  position: absolute;
  top: 50px;
  left: 200px;
  background-color: lightblue;
  min-width: 200px;
  overflow: auto;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
}

.dropdown-content a {
  color: blue;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {
    background-color: blue;
    color: white;
}

.show,.show2,.show3 {display: block;}

.dropbtn,.dropbtn2,.dropbtn3{
    color: white;
    background-color: blue;
    border: none;
    padding: 14px 16px;
    height: 45px;
}
.dropbtn:hover,.dropbtn2:hover,.dropbtn3:hover{
    background-color: lightblue;
    color: blue;
}

.dropdown-content2 {
  display: none;
  position: absolute;
  top: 50px;
  left: 200px;
  background-color: lightblue;
  min-width: 160px;
  overflow: auto;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
}

.dropdown-content2 a {
  color: blue;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content2 a:hover {
    background-color: blue;
    color: white;
}
.dropdown-content3 {
  display: none;
  position: absolute;
  top: 50px;
  left: 500px;
  background-color: lightblue;
  min-width: 160px;
  overflow: auto;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
}

.dropdown-content3 a {
  color: blue;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content3 a:hover {
    background-color: blue;
    color: white;
}
.heading span{
    background-color: lightblue;
    color: blue;
    width: 10px;
}
footer{
    background-color: black;
    height: 230px;
    margin-top: 20px;
}
footer .left{
    float: left;
    margin-left: 10%;
    width: 30%;
    color: white;
    margin-top: 20px;
}
footer .main a{
  
    text-decoration: none;
    color: white;
    font-size: 20px;
}
footer .main a:hover{
    color: blue;
}
footer .main{
    margin-top: 40px;
      float: left;
}
footer .right{
    float: left;
    color: white;
     margin-top: 20px;
}


        </style>
    </head>
    <body>
        <nav id="nav">
        <ul>
            <li><i>JOBWORLD</i></li>
            <li><a href="homepage.php">HOME</a></li>
            <li><button onclick="myFunction()" class="dropbtn">JOBS</button> </li>
                <div id="myDropdown" class="dropdown-content">
                    <a href="alljobs.php">All Jobs</a>
                     <a href="jobsbycity.php">Jobs By City</a>
                     <a href="jobsbydomain.php">Jobs By Domain</a>
                </div>
           
             <li><button onclick="myFunction2()" class="dropbtn2">INTERNSHIPS</button> </li>
            <div id="myDropdown2" class="dropdown-content">
                <a href="allinternships.php">All Internships</a>
                     <a href="internshipbycity.php">Internships By City</a>
                     <a href="internshipbydomain.php">Internships By Domain</a>
                </div>
              
             <li><button onclick="myFunction3()" class="dropbtn3">POST</button></li>     
            <div id="myDropdown3" class="dropdown-content">
                <a href="jobpost.php">Post a Job</a>
                     <a href="PostInternship.php">Post an Internship</a>
                    
                </div>
             <li><a href="resumetemplates.php">RESUME</a></li>
             <li><a href="aboutus.html">ABOUT US</a></li>
             <li style="margin-left: 30%;"><a href="myprofile.php">MY PROFILE</a></li>
        </ul>
        </nav>
        
        <h1 class="heading" style="text-align: center;">
        <span>J</span>
        <span>O</span>
        <span>B</span>
        <span>W</span>
        <span>O</span>
        <span>R</span>
        <span>L</span>
        <span>D</span>
    </h1>

        
<h2 style='font-family:calibri;font-style:italic; text-align:center; color: blue;'>"Arise, awake and stop not till the goal is achieved." - Swami Vivekananda</h2><br><br>
<main>
<p>Jobworld is a dot com business with the heart of dot org.<br><br>
    We are a technology company on a mission to equip students with relevant skills & practical exposure through internships and online trainings. Imagine a world full of freedom and possibilities. A world where you can discover your passion and turn it into your career. A world where your practical skills matter more than your university degree. A world where you do not have to wait till 21 to taste your first work experience (and get a rude shock that it is nothing like you had imagine it to be). A world where you graduate fully assured, fully confident, and fully prepared to stake claim on your place in the world.<br><br>At Jobworld, we are making this dream a reality, <a href='homepage.php'>join us!</a></p><br>
<p>India is a vast country filled with near 1.5 billion people where 20 percent are youths. With such a population and growing competition at the world stage, it is our prime responsibility to equip India, our country, with right resources and representatives. Our aim is to provide students with the right tool and opportunities where the same can prepare, develop, and deliver for himself and his countrymen. This creation and implementation are the first step towards our aim. </p><br>
<p>The initiative was inaugurated on 13th day of July in the year 2021. 
The company's business model is based on job listings and employer branding or visibility advertisements, on the one hand, and résumé database access, on the other. Additional features of the website include job seeker services such as candidate services which are free for job seekers; value-added features such as resume writing, highlighting, etc., for job seekers; and tools to search the database of resumes and job application screening programs for employer and recruitment consultant customers.
The company constantly invests in product development and improved user experiences through search tools and better site response. <a href='ourteam.php'>Our team</a> consists of very high skilled developers that have never let us down and are consistently evolving themself as well as the company. The search mechanism has been significantly improved for job search.</p><br>
<p>Going forward, the vision is to reposition jobworld.com as a complete recruitment partner by consolidating all products into a Job World Suite that caters to almost all the recruitment needs of customers.</p><br>
<p>Tenets we live by:<br>
<ul>
<li>Dream Big</li>
<li>Make it Happen</li>
<li>Pursuit for excellence and happiness</li>
<li>Master Simplicity</li>
<li>Live ethically</li>
<li>Respect All</li>
<li>Customer is King</li>
<li>Groww Together</li>
</ul></p>
</main>

<footer>
            <div class="left">
                <h2>Office Address:</h2>
                <p>B-161<br>Ashok Vihar<br>Delhi-110052<p>
            </div>
            <div class="main" style=" width: 30%; float: left">
                <a href="ourteam.php"">Our Team</a><br>
                <a href="aboutus.php">About Us</a><br>
                <a href="privacypolicy.php">Privacy Policy</a><br>
                <a href="termsnconditions.php">Terms and Conditions</a>
            </div>
            <div class="right">
                <h2>Contact Us:</h2>
                <p>+91 8826033672<br>+91 7718025123<br>+91 9869799006</p>
            </div>
        </footer>
    </body>
</html>


