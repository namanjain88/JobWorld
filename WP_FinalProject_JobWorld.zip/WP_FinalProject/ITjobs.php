<html>
    <head>
        <title>JobWorld-Home</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="homepage.css">
        <script language="javascript" src="home.js"></script>
        <link rel="icon" href="favicon.png" type="image/x-icon"/>
    </head>
    <body>
        <nav>
        <ul>
            <li><i>JOBWORLD</i></li>
            <li><a href="homepage.php">HOME</a></li>
            <li><button onclick="myFunction()" class="dropbtn">JOBS</button> </li>
                <div id="myDropdown" class="dropdown-content">
                    <a href="alljobs.php">All Jobs</a>
                     <a href="jobsbycity.php">Jobs By City</a>
                     <a href="jobsbydomain.php">Jobs By Domain</a>
                </div>
           
             <li><button onclick="myFunction2()" class="dropbtn2">INTERNSHIPS</button> </li>
            <div id="myDropdown2" class="dropdown-content">
                <a href="allinternships.php">All Internships</a>
                     <a href="internshipbycity.php">Internships By City</a>
                     <a href="internshipbydomain.php">Internships By Domain</a>
                </div>
             <li><button onclick="myFunction3()" class="dropbtn3">POST</button></li>     
            <div id="myDropdown3" class="dropdown-content">
                <a href="jobpost.php">Post a Job</a>
                     <a href="PostInternship.php">Post an Internship</a>
                    
                </div>
             <li><a href="resumetemplates.php">RESUME</a></li>
            <li><a href="aboutus.php">ABOUT US</a></li>
            <li style="margin-left: 30%;"><a href="myprofile.php">MY PROFILE</a></li>
        </ul>
        </nav>
        
        
        <h1 style="text-align: center; font-family: cursive; color: #3399FF; margin-top: 50px; font-size: 50px;">IT JOBS</h1>
        <div class="job" style="margin-top: 50px;"> 
                <img src="amazon.png" alt="amazon">
                <h2>AMAZON<br>(Web Development)</h2><br><br>
                  
                <ul>
                    <li>Start Date: 5 January 2022</li>
                    <li>Salary: 12LPA</li>   
                    <li>Work Experience: 2 years</li>
                    <li>Location: Chennai</li>
                </ul>
                <button onclick="location.href='amazonWD.php'">Know More</button>
               
        </div>
        <div class="job"> 
             <img src="flipkart.png" alt="flipkart">
                <h2>FLIPKART<br>(Data Analysis)</h2><br><br>
                <ul>
                    <li>Start Date: 20 November 2021</li>
                    <li>Salary: 15LPA</li>
                    <li>Work Experience: 5 year</li>
                    <li>Location: Mumbai</li>
                </ul>
                <button>Know More</button>
        </div>
        <div class="job"> 
                 <img src="infosys.png" alt="Infosys">
                <h2>Infosys<br>(Software Development)</h2><br><br>
                <ul>
                    <li>Start Date: 2 December2021</li>
                    <li>Salary: 12LPA</li>
                    <li>Work Experience: 1.5 year</li>
                    <li>Location: Mumbai</li>
                </ul>
                <button>Know More</button>
        </div>
        <div class="job"> 
             <img src="tcs.png" alt="TCS">
                <h2>Tata Consultancy Services<br>(Software Development)</h2><br><br>
                <ul>
                    <li>Start Date: 15 October 2021</li>
                    <li>Salary: 11 LPA</li>
                    <li>Work Experience: 6 months</li>
                    <li>Location: Bangalore</li>
                </ul>
                <button>Know More</button>
        </div>
        <div class="job"> 
             <img src="hcl.png" alt="HCL">
                <h2>Hindustan Computers Limited<br>(Web Development)</h2><br><br>
                <ul>
                    <li>Start Date: 2 October 2021</li>
                    <li>Salary: 10 LPA</li>
                    <li>Work Experience: 6 months</li>
                    <li>Location: Hyderabad </li>
                </ul>
                <button>Know More</button>
        </div>
        <div class="job"> 
             <img src="wipro.png" alt="Wipro">
                <h2>Wipro<br>(Data Analysis)</h2><br><br>
                <ul>
                    <li>Start Date: 15 November 2021</li>
                    <li>Salary: 9 LPA</li>
                    <li>Work Experience: 1 year</li>
                    <li>Location: Mumbai</li>
                </ul>
                <button>Know More</button>
        </div>
        <div class="job"> 
             <img src="accenture.png" alt="Accenture">
                <h2>Accenture<br>(Data Analysis)</h2><br><br>
                <ul>
                    <li>Start Date:17 October 2021</li>
                    <li>Salary: 11.5LPA</li>
                    <li>Work Experience: 1 year</li>
                    <li>Location: Delhi</li>
                </ul>
                <button>Know More</button>
        </div>
        <div class="job"> 
             <img src="paytm.png" alt="Paytm">
                <h2>Paytm <br>(Data Analysis)</h2><br><br>
                <ul>
                    <li>Start Date: 20 November 2021</li>
                    <li>Salary: 15LPA</li>
                    <li>Work Experience: 1 year</li>
                    <li>Location: Mumbai</li>
                </ul>
                <button>Know More</button>
        </div>
        <div class="job"> 
             <img src="google.png" alt="Google">
                <h2>Google<br>(Data Analysis)</h2><br><br>
                <ul>
                    <li>Start Date: 16 November 2021</li>
                    <li>Salary: 12.5LPA</li>
                    <li>Work Experience: 1 year</li>
                    <li>Location: Mumbai</li>
                </ul>
                <button>Know More</button>
        </div>
        <div class="job"> 
            <img src="IBM.png" alt="IBM ">
                <h2>IBM <br>(Software Developer)</h2><br><br>
                <ul>
                    <li>Start Date: 3 March 2022</li>
                    <li>Salary: 7 LPA</li>
                    <li>Work Experience: 1.5 year</li>
                    <li>Location: Bangalore</li>
                </ul>
                <button>Know More</button>
        </div>
        
        
        
        <footer>
            <div class="left">
                <h2>Office Address:</h2>
                <p>B-161<br>Ashok Vihar<br>Delhi-110052<p>
            </div>
            <div class="main" style=" width: 30%; float: left">
                <a href="ourteam.php"">Our Team</a><br>
                <a href="aboutus.php">About Us</a><br>
                <a href="privacypolicy.php">Privacy Policy</a><br>
                <a href="termsnconditions.php">Terms and Conditions</a>
            </div>
            <div class="right">
                <h2>Contact Us:</h2>
                <p>+91 8826033672<br>+91 7718025123<br>+91 9869799006</p>
            </div>
        </footer>

    </body>
</html>


