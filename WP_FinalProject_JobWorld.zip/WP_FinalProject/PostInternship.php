<!DOCTYPE html>
<html lang="en-us">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title> Post an internship</title>
        <link rel="icon" href="favicon.png" type="image/x-icon"/>
        <link rel="stylesheet" href="postInternship.css">
         <script>
        function myFunction3() {
  document.getElementById("myDropdown3").classList.toggle("show3");
}

window.onclick = function(event) {
  if (!event.target.matches('.dropbtn3')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show3')) {
        openDropdown.classList.remove('show3');
      }
    }
  }
}</script>
</head>


<body>
     <nav>
        <ul>
            <li><i>JOBWORLD</i></li>
            <li><a href="homepage.php">HOME</a></li>
            <li><button onclick="myFunction()" class="dropbtn">JOBS</button> </li>
                <div id="myDropdown" class="dropdown-content">
                    <a href="alljobs.php">All Jobs</a>
                     <a href="jobsbycity.php">Jobs By City</a>
                     <a href="jobsbydomain.php">Jobs By Domain</a>
                </div>
           
             <li><button onclick="myFunction2()" class="dropbtn2">INTERNSHIPS</button> </li>
            <div id="myDropdown2" class="dropdown-content">
                <a href="allinternships.php">All Internships</a>
                     <a href="internshipbycity.php">Internships By City</a>
                     <a href="internshipbydomain.php">Internships By Domain</a>
                </div>
             <li><button onclick="myFunction3()" class="dropbtn3">POST</button></li>     
            <div id="myDropdown3" class="dropdown-content">
                <a href="jobpost.php">Post a Job</a>
                     <a href="PostInternship.php">Post an Internship</a>
                    
                </div>
             <li><a href="resumetemplates.php">RESUME</a></li>
            <li><a href="aboutus.php">ABOUT US</a></li>
            <li style="margin-left: 30%;"><a href="myprofile.php">MY PROFILE</a></li>
        </ul>
        </nav>
    <main>
    <h2 style="color:#3399FF; text-align: center">Post an Internship Application</h2><br>
    <form>
<p>About your Company: </p>
<label for='img'>Upload logo:</label><br>
<input type='file' id='img' name='img'><br><br>
Company Name:<br><input type='text' style='width:50%' placeholder='Enter Your Company name'><br><br>
Enter company's website:<br><input type='url' placeholder='For example: https://www.jobsworld.com' size='50'><br><br>
<p >About the Intership: </p>
Job Title:<br><input type='text' style='width:50%' placeholder='Enter Job Title'><br><br>
Location:<br><input type='text' style='width:50%' placeholder='Enter Location for internship'><br><br>
Start Date:<br><input type="text" placeholder="Select start date" size='15' onfocus="(this.type='date')"><br><br>
Duration:<br><input type="number" placeholder="Enter duration" style='width:106px'> <select><option>Weeks</option><option>Months</option></select><br><br>
Stipend:<br>
INR: <input type='number' style='width:75px'> Per: <select><option>Month</option><option>Week</option><option>Day</option></select><br><br>
Last date for application:<br><input type="text" placeholder="Apply By" size='15' onfocus="(this.type='date')"><br><br>
Additional Remarks:<br><textarea rows='6' cols='45' placeholder="Remarks"></textarea><br><br></textarea>
 No of Candidates Required:<br><input type='number' style='width:75px'><br><br><br>
<p>Other Details: -</p>
Intership Description:<br><textarea rows='5' cols='100' style='width:50%' placeholder="Description"></textarea><br><br></textarea><br>
Skills Required:<br><textarea rows='5' cols='50' placeholder="Skills Required"></textarea><br><br></textarea><br>
Perks:<br><textarea rows='5' cols='40' placeholder="Perks"></textarea><br><br></textarea><br>
Additional Information (if any):<br><textarea rows='6' cols='45' placeholder="Additional Information"></textarea><br><br></textarea><br>
<button>SUBMIT</button>
</form>
    </main>
    <footer>
            <div class="left">
                <h2>Office Address:</h2>
                <p>B-161<br>Ashok Vihar<br>Delhi-110052<p>
            </div>
            <div class="main" style=" width: 30%; float: left">
                <a href="ourteam.php"">Our Team</a><br>
                <a href="aboutus.php">About Us</a><br>
                <a href="privacypolicy.php">Privacy Policy</a><br>
                <a href="termsnconditions.php">Terms and Conditions</a>
            </div>
            <div class="right">
                <h2>Contact Us:</h2>
                <p>+91 8826033672<br>+91 7718025123<br>+91 9869799006</p>
            </div>
        </footer>
    
</body>
</html>

