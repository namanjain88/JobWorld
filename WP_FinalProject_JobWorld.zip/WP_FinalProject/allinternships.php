<html>
    <head>
        <title>All Jobs</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="homepage.css">
        <script language="javascript" src="home.js"></script>
        <link rel="icon" href="favicon.png" type="image/x-icon"/>
        <script>
        function myFunction3() {
  document.getElementById("myDropdown3").classList.toggle("show3");
}

window.onclick = function(event) {
  if (!event.target.matches('.dropbtn3')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show3')) {
        openDropdown.classList.remove('show3');
      }
    }
  }
}</script>
    <style>
        form input{
            margin-left: 30%;
            margin-top: 10px;
            width: 30%;
            height: 30px;
            border: solid;
            
        }
   
        </style>
    </head>
    <body>
        <nav id="nav">
        <ul>
            <li><i>JOBWORLD</i></li>
            <li><a href="homepage.php">HOME</a></li>
            <li><button onclick="myFunction()" class="dropbtn">JOBS</button> </li>
                <div id="myDropdown" class="dropdown-content">
                    <a href="alljobs.php">All Jobs</a>
                     <a href="jobsbycity.php">Jobs By City</a>
                     <a href="jobsbydomain.php">Jobs By Domain</a>
                </div>
           
             <li><button onclick="myFunction2()" class="dropbtn2">INTERNSHIPS</button> </li>
            <div id="myDropdown2" class="dropdown-content">
                <a href="allinternships.php">All Internships</a>
                     <a href="internshipbycity.php">Internships By City</a>
                     <a href="internshipbydomain.php">Internships By Domain</a>
                </div>
              
             <li><button onclick="myFunction3()" class="dropbtn3">POST</button></li>     
            <div id="myDropdown3" class="dropdown-content">
                <a href="jobpost.php">Post a Job</a>
                     <a href="PostInternship.php">Post an Internship</a>
                    
                </div>
             <li><a href="resumetemplates.php" class="favourites">RESUME</a></li>
             <li><a href="aboutus.php">ABOUT US</a></li>
             <li style="margin-left: 30%;"><a href="myprofile.php">MY PROFILE</a></li>
        </ul>
        </nav>
        
        <form>
            <input type="search" name="search" placeholder="Search" id="searchbar">
        </form>
        <script>
            var search_input=document.querySelector("#searchbar");
            search_input.addEventListener("keyup",function(e){
                console.log(e.target.value)
                var search_item=e.target.value;
                var span_items=document.querySelectorAll(".job")
                span_items.forEach(function(job){
                    if(job.textContent.indexOf(search_item)!=-1){
                        job.closest(".job").style.display="block";
                    }
                    else{
                         job.closest(".job").style.display="none";
                    }
                })
            })
        </script>
       
        <div class="job"> 
             <img src="flipkart.png" alt="flipkart">
                <h2>FLIPKART<br>(Marketing)</h2><br><br>
                <ul>
                    <li>Start Date: 20 November 2021</li>
                    <li>Stipend: 15000/-</li>
                    <li>Duration: 1 month</li>
                    <li>Location: Mumbai</li>
                </ul>
                <button onclick="location.href='flipkartMark.php'">Know More</button>
        </div>
        <div class="job"> 
             <img src="edy.png" alt="EdYoda - Zekelabs Technology">
             <h2>EdYoda - Zekelabs Technology<br>(Business Development - Sales)</h2><br><br>
                <ul>
                    <li>Start Date: 25 November 2021</li>
                    <li>Stipend: 12500/-</li>
                    <li>Duration: 3 month</li>
                    <li>Location: Bangalore</li>
                </ul>
                <button onclick="location.href='edyodaBMS.php'">Know More</button>
        </div>
        <div class="job"> 
             <img src="paytm.png" alt="Paytm">
                <h2>Paytm <br>(Finance)</h2><br><br>
                <ul>
                    <li>Start Date: 20 November 2021</li>
                    <li>Stipend: 1500/-</li>
                    <li>Duration: 1 month</li>
                    <li>Location: Mumbai</li>
                </ul>
                <button onclick="location.href='paytmFin.php'">Know More</button>
        </div>
        <div class="job"> 
             <img src="tcs.png" alt="TCS">
                <h2>Tata Consultancy Services<br>(Software Development)</h2><br><br>
                <ul>
                    <li>Start Date: 15 October 2021</li>
                    <li>Stipend: 11000/-</li>
                    <li>Duration: 6 months</li>
                    <li>Location: Banglore</li>
                </ul>
                <button onclick="location.href='tcsSD.php'">Know More</button>
        </div>
        <div class="job"> 
             <img src="hcl.png" alt="HCL">
                <h2>Hindustan Computers Limited<br>(Digital Marketing)</h2><br><br>
                <ul>
                    <li>Start Date: 2 October 2021</li>
                    <li>Stipend: 5000/-</li>
                    <li>Duration: 2 months</li>
                    <li>Location: Hyderabad </li>
                </ul>
                <button onclick="location.href='hclDM.php'">Know More</button>
        </div>
        <div class="job" style="margin-top: 50px;"> 
                <img src="amazon.png" alt="amazon">
                <h2>AMAZON<br>(Web Development)</h2><br><br>
                  
                <ul>
                    <li>Start Date: 5 January 2022</li>
                    <li>Stipend: 20000/-</li>   
                    <li>Duration: 2 months</li>
                    <li>Location: Chennai</li>
                </ul>
                <button>Know More</button>
               
        </div>
         
                </div>
        <div class="job"> 
                 <img src="infosys.png" alt="Infosys">
                <h2>Infosys<br>(Software Development)</h2><br><br>
                <ul>
                    <li>Start Date: 2 December2021</li>
                    <li>Stipend: 12000/-</li>
                    <li>Duration: 2 months</li>
                    <li>Location: Mumbai</li>
                </ul>
                <button>Know More</button>
        </div>
         
        
         
         <div class="job"> 
             <img src="wipro.png" alt="Wipro">
                <h2>Wipro<br>(Management)</h2><br><br>
                <ul>
                    <li>Start Date: 15 November 2021</li>
                    <li>Stipend: 9000/-</li>
                    <li>Duration: 3 months</li>
                    <li>Location: Mumbai</li>
                </ul>
                <button>Know More</button>
        </div>
         <div class="job"> 
             <img src="accenture.png" alt="Accenture">
                <h2>Accenture<br>(Data Analysis)</h2><br><br>
                <ul>
                    <li>Start Date:17 October 2021</li>
                    <li>Stipend: 11000/-</li>
                    <li>Duration: 2 months</li>
                    <li>Location: Work From Home</li>
                </ul>
                <button>Know More</button>
        </div>
        
         
        
         <div class="job"> 
             <img src="google.png" alt="Google">
                <h2>Google<br>(Data Analysis)</h2><br><br>
                <ul>
                    <li>Start Date: 16 November 2021</li>
                    <li>Salary: 12000/-</li>
                    <li>Duration: 1 month</li>
                    <li>Location: Mumbai</li>
                </ul>
                <button>Know More</button>
        </div>
        
         <div class="job"> 
             <img src="microsoft.png" alt="Microsoft">
                <h2>Microsoft<br>(Software Developer)</h2><br><br>
                <ul>
                    <li>Start Date: 3 January 2022</li>
                    <li>Salary: 12000/-</li>
                    <li>Duration: 3 month</li>
                    <li>Location: Bangalore</li>
                </ul>
                <button>Know More</button>
        </div>
        <div class="job"> 
            <img src="IBM.png" alt="IBM ">
                <h2>IBM <br>(Software Developer)</h2><br><br>
                <ul>
                    <li>Start Date: 3 March 2022</li>
                    <li>Stipend: 7000/-</li>
                    <li>Duration: 1.5 months</li>
                    <li>Location: Banglore</li>
                </ul>
                <button>Know More</button>
        </div>
        <div class="job"> 
            <img src="intel.jpg" alt="Intel ">
                <h2>Intel <br>(PCB Designing)</h2><br><br>
                <ul>
                    <li>Start Date: 2 Feburary 2022</li>
                    <li>Stipend: 1500/-</li>
                    <li>Duration: 1 month</li>
                    <li>Location: Hyderabad</li>
                </ul>
                <button>Know More</button>
        </div>
        
          <div class="job" style="margin-top: 50px;"> 
                <img src="jus.png" alt="Jus'Trufs">
                <h2>Jus'Trufs <br>(Digital Marketing)</h2><br><br>
                  
                <ul>
                    <li>Start Date: Starts Immediately</li>
                    <li>Stipend: 8000/-</li>   
                    <li>Duration: 3 months</li>
                    <li>Location: Bangalore</li>
                </ul>
                <button onclick="location.href=''">Know More</button>
               
        </div>
	
         
	
         <div class="job"> 
             <img src="kwh.png" alt="KWh Bikes">
             <h2>KWh Bikes<br>(Mechanical Engineering)</h2><br><br>
                <ul>
                    <li>Start Date: 11 November 2021</li>
                    <li>Stipend: 5000/-</li>
                    <li>Duration: 4 month</li>
                    <li>Location: Bangalore</li>
                </ul>
                <button>Know More</button>
        </div>
	
        <div class="job"> 
                 <img src="hello.png" alt="HelloSivi">
                 <h2>HelloSivi<br>(System Programming - C/C++)</h2><br><br>
                <ul>
                    <li>Start Date: 1 January 2022</li>
                    <li>Stipend: 12000/-</li>
                    <li>Duration: 2 months</li>
                    <li>Location: Bangalore</li>
                </ul>
                <button>Know More</button>
        </div>
	
         <div class="job"> 
             <img src="buzz.png" alt="Buzzlink Studios">
             <h2>Buzzlink Studios<br>(Graphic Design)</h2><br><br>
                <ul>
                    <li>Start Date: Starts Immediately</li>
                    <li>Stipend: 15000/-</li>
                    <li>Duration: 3 months</li>
                    <li>Location: Bangalore</li>
                </ul>
                <button>Know More</button>
        </div>
       
         <div class="job"> 
             <img src="jh.png" alt="Jetic Healthcare Pvt. Ltd.">
             <h2>Jetic Healthcare Pvt. Ltd.<br>(Biomedical - Pharmaceutical)</h2><br><br>
                <ul>
                    <li>Start Date: Start Immediately</li>
                    <li>Salary: 2000/-</li>
                    <li>Duration: 6 months</li>
                    <li>Location: Bangalore</li>
                </ul>
                <button>Know More</button>
        </div>
	
         <div class="job"> 
             <img src="gm.png" alt="GetMega">
             <h2>GetMega<br>(Marketing)</h2><br><br>
                <ul>
                    <li>Start Date: 15 October 2021</li>
                    <li>Salary: 7500/-</li>
                    <li>Duration: 2 months</li>
                    <li>Location: Bangalore</li>
                </ul>
                <button>Know More</button>
        </div>
	
        
         <div class="job" style="margin-top: 50px;"> 
                <img src="sko.png" alt="Skooly">
                <h2>Skooly<br>(Java Development)</h2><br><br>
                  
                <ul>
                    <li>Start Date: Starts Immediately</li>
                    <li>Stipend: 12000/-</li>   
                    <li>Duration: 2 months</li>
                    <li>Location: Chennai</li>
                </ul>
                <button onclick="location.href=''">Know More</button>
               
        </div>

         <div class="job"> 
             <img src="block.png" alt="BLOCK X">
             <h2>BLOCK X<br>(Business Strategy)</h2><br><br>
                <ul>
                    <li>Start Date: 25 November 2021</li>
                    <li>Stipend: 5000/-</li>
                    <li>Duration: 2 month</li>
                    <li>Location: Chennai</li>
                </ul>
                <button>Know More</button>
        </div>
	
         <div class="job"> 
             <img src="taizo.png" alt="Taizo Technologies Pvt. Ltd.">
             <h2>Taizo Technologies Pvt. Ltd.<br>(Social Media Marketing)</h2><br><br>
                <ul>
                    <li>Start Date: 5 November 2021</li>
                    <li>Stipend: 3000/-</li>
                    <li>Duration: 3 month</li>
                    <li>Location: Chennai</li>
                </ul>
                <button>Know More</button>
        </div>

        <div class="job"> 
                 <img src="almi.png" alt="Almi Blogging School Pro">
                 <h2>HelloSivi<br>(Content Writing)</h2><br><br>
                <ul>
                    <li>Start Date: 1 January 2022</li>
                    <li>Stipend: 12000/-</li>
                    <li>Duration: 2 months</li>
                    <li>Location: Chennai</li>
                </ul>
                <button>Know More</button>
        </div>
	
         <div class="job"> 
             <img src="earning.png" alt="Earning Designs Pvt. Ltd.">
             <h2>Earning Designs Pvt. Ltd.<br>(Backend Development)</h2><br><br>
                <ul>
                    <li>Start Date: Starts Immediately</li>
                    <li>Stipend: 10000/-</li>
                    <li>Duration: 6 months</li>
                    <li>Location: Chennai</li>
                </ul>
                <button>Know More</button>
        </div>
        
         <div class="job"> 
             <img src="feednet.png" alt="Feednet Solutions Pvt. Ltd.">
                <h2>Feednet Solutions Pvt. Ltd.<br>(Azure Development)</h2><br><br>
                <ul>
                    <li>Start Date: Start Immediately</li>
                    <li>Salary: 9000/-</li>
                    <li>Duration: 3 months</li>
                    <li>Location: Chennai</li>
                </ul>
                <button>Know More</button>
        </div>
	
         <div class="job"> 
             <img src="smt.png" alt="Smart Accountants">
                <h2>Smart Accountants<br>(Accounts)</h2><br><br>
                <ul>
                    <li>Start Date: 15 October 2021</li>
                    <li>Salary: 4500/-</li>
                    <li>Duration: 6 months</li>
                    <li>Location: Chennai</li>
                </ul>
                <button>Know More</button>
        </div>
	

         <div class="job" style="margin-top: 50px;"> 
                <img src="aarvy.png" alt="Aarvy Technologies">
                <h2>Aarvy Technologies<br>(Node.js Development)</h2><br><br>
                  
                <ul>
                    <li>Start Date: Starts Immediately</li>
                    <li>Stipend: 10000/-</li>   
                    <li>Duration: 6 months</li>
                    <li>Location: Delhi</li>
                </ul>
                <button onclick="location.href=''">Know More</button>
               
        </div>
	
         <div class="job"> 
             <img src="kripya.png" alt="Kripya Solutions Pvt. Ltd.">
                <h2>Kripya Solutions<br>(Web Development)</h2><br><br>
                <ul>
                    <li>Start Date: Starts Immediately</li>
                    <li>Stipend: 10000/-</li>
                    <li>Duration: 3 month</li>
                    <li>Location: Delhi</li>
                </ul>
                <button>Know More</button>
        </div>
	
        <div class="job"> 
                 <img src="peppermint.png" alt="Peppermint Communications">
                <h2>Peppermint Communications<br>(Event Promotions)</h2><br><br>
                <ul>
                    <li>Start Date: 2 December 2021</li>
                    <li>Stipend: 6000/-</li>
                    <li>Duration: 6 months</li>
                    <li>Location: Delhi</li>
                </ul>
                <button>Know More</button>
        </div>
	
         <div class="job"> 
             <img src="bbd.png" alt="Baar Baar Dekho">
                <h2>Baar Baar Dekho<br>(Video Making/Editing)</h2><br><br>
                <ul>
                    <li>Start Date: 1 Febuary 2022</li>
                    <li>Stipend: 1500/-</li>
                    <li>Duration: 6 months</li>
                    <li>Location: Delhi</li>
                </ul>
                <button>Know More</button>
        </div>
        
         <div class="job"> 
             <img src="irs.png" alt="Indian Robo Store">
                <h2>Indian Robo Store<br>(Human Resources)</h2><br><br>
                <ul>
                    <li>Start Date: 2 October 2021</li>
                    <li>Salary: 10000/-</li>
                    <li>Duration: 4 months</li>
                    <li>Location: Delhi, Noida </li>
                </ul>
                <button>Know More</button>
        </div>
	
         <div class="job"> 
             <img src="fpc.png" alt="First Point Creations">
                <h2>First Point Creations<br>(Digital Marketing)</h2><br><br>
                <ul>
                    <li>Start Date: 15 December 2021</li>
                    <li>Stipend: 3000/-</li>
                    <li>Duration: 5 months</li>
                    <li>Location: Delhi, Bahadurgarh</li>
                </ul>
                <button>Know More</button>
        </div>
	
         <div class="job"> 
             <img src="decathlon.png" alt="Decathlon Sports India">
                <h2>Decathlon Sports India<br>(Business Development - Sales)</h2><br><br>
                <ul>
                    <li>Start Date:1 January 2022</li>
                    <li>Stipend: 10000/-</li>
                    <li>Duration: 3 months</li>
                    <li>Location: Delhi</li>
                </ul>
                <button>Know More</button>
        </div>
	
        
         <div class="job" style="margin-top: 50px;"> 
                <img src="quanint.png" alt="Quanint Techsoft Pvt. Ltd.">
                <h2>Quanint Techsoft Pvt. Ltd.<br>(Socail Media Marketing)</h2><br><br>
                  
                <ul>
                    <li>Start Date: Starts Immediately</li>
                    <li>Stipend: 4000/-</li>   
                    <li>Duration: 3 months</li>
                    <li>Location: Hyderabad</li>
                </ul>
                <button onclick="location.href=''">Know More</button>
               
        </div>
	
         <div class="job"> 
             <img src="hcb.png" alt="Hyderabad Coach Buliders Pvt. Ltd.">
                <h2>Hyderabad Coach Buliders Pvt. Ltd.<br>(Marketing)</h2><br><br>
                <ul>
                    <li>Start Date: Starts Immediately</li>
                    <li>Stipend: 10000/-</li>
                    <li>Duration: 6 month</li>
                    <li>Location: Hyderabad</li>
                </ul>
                <button>Know More</button>
        </div>
	
        <div class="job"> 
                 <img src="tt.png" alt="Techieyan Technologies">
                <h2>Techieyan Technologies<br>(Robotics & Embedded Systems)</h2><br><br>
                <ul>
                    <li>Start Date: 3 December 2021</li>
                    <li>Stipend: 6000/-</li>
                    <li>Duration: 6 months</li>
                    <li>Location: Hyderabad</li>
                </ul>
                <button>Know More</button>
        </div>
	<br><br>
         <div class="job"> 
             <img src="sl.png" alt="Startoon Labs Pvt. Ltd.">
                <h2>Starloon Labs Pvt. Ltd.<br>(Industrial Design)</h2><br><br>
                <ul>
                    <li>Start Date: 1 January 2022</li>
                    <li>Stipend: 1500/-</li>
                    <li>Duration: 6 months</li>
                    <li>Location: Hyderabad</li>
                </ul>
                <button>Know More</button>
        </div>
        
         <div class="job"> 
             <img src="wms.png" alt="WeMakeScholars">
                <h2>WeMakeScholars<br>(Sales)</h2><br><br>
                <ul>
                    <li>Start Date: 30 October 2021</li>
                    <li>Salary: 17000/-</li>
                    <li>Duration: 6 months</li>
                    <li>Location: Hyderabad </li>
                </ul>
                <button>Know More</button>
        </div>
	<br><br>
         <div class="job"> 
             <img src="unio.png" alt="UNIO Labs">
                <h2>UNIO Labs<br>(Flutter Development)</h2><br><br>
                <ul>
                    <li>Start Date: 15 October 2021</li>
                    <li>Salary: 7000/-</li>
                    <li>Duration: 3 months</li>
                    <li>Location: Hyderabad </li>
                </ul>
                <button>Know More</button>
        </div>
	
        
        <div class="job" style="margin-top: 50px;"> 
                <img src="sigaram.png" alt="Sigaram Technologies">
                <h2>Sigaram Technologies<br>(Website & Mobile App Testing)</h2><br><br>
                  
                <ul>
                    <li>Start Date: Starts Immediately</li>
                    <li>Stipend: 10000/-</li>   
                    <li>Duration: 6 months</li>
                    <li>Location: Kolkata</li>
                </ul>
                <button onclick="location.href=''">Know More</button>
               
        </div>
	
         <div class="job"> 
             <img src="ttl.png" alt="Thinking Tree Learning Pvt. Ltd.">
                <h2>Thinking Tree Learning Pvt. Ltd.<br>(Operations)</h2><br><br>
                <ul>
                    <li>Start Date: 15 November 2021</li>
                    <li>Stipend: 18000/-</li>
                    <li>Duration: 6 month</li>
                    <li>Location: Kolkata</li>
                </ul>
                <button>Know More</button>
        </div>
	
        <div class="job"> 
                 <img src="gifts.png" alt="GiftstoIndia24X7.com">
                <h2>GiftstoIndia24X7.com<br>(E-Commerce Assistance)</h2><br><br>
                <ul>
                    <li>Start Date: 1 December 2021</li>
                    <li>Stipend: 15000/-</li>
                    <li>Duration: 6 months</li>
                    <li>Location: Kolkata</li>
                </ul>
                <button>Know More</button>
        </div>
	
         <div class="job"> 
             <img src="gifts.png" alt="GiftstoIndia24X7.com.">
                <h2>GiftstoIndia24X7.com<br>(Content Writing)</h2><br><br>
                <ul>
                    <li>Start Date: Starts Immediately</li>
                    <li>Stipend: 15000/-</li>
                    <li>Duration: 6 months</li>
                    <li>Location: Kolkata</li>
                </ul>
                <button>Know More</button>
        </div>
        
         <div class="job"> 
             <img src="garg.png" alt="Garg Marketing Pvt. Ltd.">
                <h2>Garg Marketing Pvt. Ltd.<br>(Marketing)</h2><br><br>
                <ul>
                    <li>Start Date: 30 October 2021</li>
                    <li>Salary: 17000/-</li>
                    <li>Duration: 6 months</li>
                    <li>Location: Kolkata </li>
                </ul>
                <button>Know More</button>
        </div>
	
         <div class="job"> 
             <img src="simco.png" alt="Simco Consultancy">
                <h2>Simco Consultancy<br>(Finance)</h2><br><br>
                <ul>
                    <li>Start Date: 15 October 2021</li>
                    <li>Salary: 4000/-</li>
                    <li>Duration: 2 months</li>
                    <li>Location: Kolkata </li>
                </ul>
                <button>Know More</button>
        </div>
	
        
         <div class="job" style="margin-top: 50px;"> 
                <img src="urbancompany.png" alt="Urban Company">
                <h2>Urban Company<br>(Operational Management)</h2><br><br>
                  
                <ul>
                    <li>Start Date: Starts Immediately</li>
                    <li>Stipend: 10000/-</li>   
                    <li>Duration: 3 months</li>
                    <li>Location: Mumbai</li>
                </ul>
                <button onclick="location.href=''">Know More</button>
               
        </div>
	
         <div class="job"> 
             <img src="flipkart.png" alt="flipkart">
                <h2>FLIPKART<br>(Marketing)</h2><br><br>
                <ul>
                    <li>Start Date: 20 November 2021</li>
                    <li>Stipend: 15000/-</li>
                    <li>Duration: 1 month</li>
                    <li>Location: Mumbai</li>
                </ul>
                <button>Know More</button>
        </div>
	
             <div class="job"> 
                 <img src="psyber.png" alt="PSYBER">
                <h2>Psyber Incorporation<br>(Front End Development)</h2><br><br>
                <ul>
                    <li>Start Date: 2 December2021</li>
                    <li>Stipend: 3000/-</li>
                    <li>Duration: 2 months</li>
                    <li>Location: Mumbai</li>
                </ul>
                <button>Know More</button>
        </div>
	
         <div class="job"> 
             <img src="oracura.png" alt="TCS">
                <h2>Oracura Solutions<br>(Business Development - Sales)</h2><br><br>
                <ul>
                    <li>Start Date: 30 October 2021</li>
                    <li>Stipend: 15000/-</li>
                    <li>Duration: 6 months</li>
                    <li>Location: Mumbai</li>
                </ul>
                <button>Know More</button>
        </div>
       
         <div class="job"> 
             <img src="tag8.png" alt="Tag8">
                <h2>Tag8<br>(Digital Marketing)</h2><br><br>
                <ul>
                    <li>Start Date: 2 October 2021</li>
                    <li>Salary: 7500/-</li>
                    <li>Duration: 4 months</li>
                    <li>Location: Mumbai </li>
                </ul>
                <button>Know More</button>
        </div>
	
         <div class="job"> 
             <img src="yog.png" alt="YogLove">
                <h2>Yog Love<br>(Graphic Design)</h2><br><br>
                <ul>
                    <li>Start Date: 15 November 2021</li>
                    <li>Stipend: 10000/-</li>
                    <li>Duration: 6 months</li>
                    <li>Location: Mumbai</li>
                </ul>
                <button>Know More</button>
        </div>
	
         <div class="job"> 
             <img src="ruby.png" alt="Ruby Capital">
                <h2>Ruby Capital<br>(Financial Analysis)</h2><br><br>
                <ul>
                    <li>Start Date:1 January 2022</li>
                    <li>Stipend: 8000/-</li>
                    <li>Duration: 3 months</li>
                    <li>Location: Mumbai</li>
                </ul>
                <button>Know More</button>
        </div>
	<br><br>
         <div class="job"> 
             <img src="rb.png" alt="RB Tyres">
                <h2>RB Tyres<br>(Accounts)</h2><br><br>
                <ul>
                    <li>Start Date: Starts Immediately</li>
                    <li>Salary: 5000/-</li>
                    <li>Duration: 6 month</li>
                    <li>Location: Mumbai</li>
                </ul>
                <button>Know More</button>
        </div>
	
         <div class="job"> 
             <img src="twl.png" alt="The Whiz Lab">
                <h2>The Whiz Lab<br>(Mechanical Engineering & Product Design)</h2><br><br>
                <ul>
                    <li>Start Date: 30 November 2021</li>
                    <li>Salary: 12000/-</li>
                    <li>Duration: 6 month</li>
                    <li>Location: Mumbai</li>
                </ul>
                <button>Know More</button>
        </div>
        
         <div class="job"> 
             <img src="psc.png" alt="Prajna Self Care">
                <h2>Prajna Self Care<br>(Pharmaceutical)</h2><br><br>
                <ul>
                    <li>Start Date: 3 January 2022</li>
                    <li>Salary: 12000/-</li>
                    <li>Duration: 3 month</li>
                    <li>Location: Mumbai</li>
                </ul>
                <button>Know More</button>
        </div>
	
        <div class="job"> 
            <img src="cisco.png" alt="Cisco ">
                <h2>Cisco<br>(Software Tester)</h2><br><br>
                <ul>
                    <li>Start Date: 3 March 2022</li>
                    <li>Stipend: 7000/-</li>
                    <li>Duration: 1.5 months</li>
                    <li>Location: Mumbai</li>
                </ul>
                <button>Know More</button>
        </div>
	
        
        <div class="job" style="margin-top: 50px;"> 
                <img src="apohan.png" alt="Apohan Corporate Consultants Pvt. Ltd.">
                <h2>Apohan Corporate Consultants Pvt. Ltd.<br>(Marketing)</h2><br><br>
                  
                <ul>
                    <li>Start Date: Starts Immediately</li>
                    <li>Stipend: 3000/-</li>   
                    <li>Duration: 6 months</li>
                    <li>Location: Pune</li>
                </ul>
                <button onclick="location.href=''">Know More</button>
               
        </div>
	
         <div class="job"> 
             <img src="akshay.png" alt="Akshay Organics Pvt. Ltd.">
                <h2>Akshay Organics Pvt. Ltd.<br>(Operations)</h2><br><br>
                <ul>
                    <li>Start Date: 25 November 2021</li>
                    <li>Stipend: 5000/-</li>
                    <li>Duration: 3 month</li>
                    <li>Location: Pune</li>
                </ul>
                <button>Know More</button>
        </div>
	
         <div class="job"> 
             <img src="kalpins.png" alt="Kalpins Marketing Solutions">
                <h2>Kalpins Marketing Solutions<br>(Web Development)</h2><br><br>
                <ul>
                    <li>Start Date: 15 November 2021</li>
                    <li>Stipend: 18000/-</li>
                    <li>Duration: 6 month</li>
                    <li>Location: Pune</li>
                </ul>
                <button>Know More</button>
        </div>
	
             <div class="job"> 
                 <img src="nocca.png" alt="Nocca Robotics">
                <h2>Nocca Robotics<br>(UX/UI Design)</h2><br><br>
                <ul>
                    <li>Start Date: 1 December 2021</li>
                    <li>Stipend: 20000/-</li>
                    <li>Duration: 2 months</li>
                    <li>Location: Pune</li>
                </ul>
                <button>Know More</button>
        </div>
	
         <div class="job"> 
             <img src="inno.png" alt="InnoThoughts">
                <h2>InnoThoughts<br>(Content Writing)</h2><br><br>
                <ul>
                    <li>Start Date: Starts Immediately</li>
                    <li>Stipend: 5000/-</li>
                    <li>Duration: 6 months</li>
                    <li>Location: Pune</li>
                </ul>
                <button>Know More</button>
        </div>
        
         <div class="job"> 
             <img src="ixp.png" alt="ImaginXP">
                <h2>ImaginXP<br>(Human Resources)</h2><br><br>
                <ul>
                    <li>Start Date: 30 December 2021</li>
                    <li>Salary: 6000/-</li>
                    <li>Duration: 4 months</li>
                    <li>Location: Pune </li>
                </ul>
                <button>Know More</button>
        </div>
	
         <div class="job"> 
             <img src="zoopero.png" alt="Zoopero Marketing Pvt. Ltd.">
                <h2>Zoopero Marketing Pvt. Ltd.<br>(Administration)</h2><br><br>
                <ul>
                    <li>Start Date: 15 January 2022</li>
                    <li>Salary: 5000/-</li>
                    <li>Duration: 5 months</li>
                    <li>Location: Pune </li>
                </ul>
                <button>Know More</button>
        </div>
	
        
        <div class="job" style="margin-top: 50px;"> 
                <img src="lk.png" alt="L.K. Stones">
                <h2>L.K. Stones<br>(Digital Marketing)</h2><br><br>
                  
                <ul>
                    <li>Start Date: Starts Immediately</li>
                    <li>Stipend: 3000/-</li>   
                    <li>Duration: 1 months</li>
                    <li>Location: Work from Home</li>
                </ul>
                <button onclick="location.href=''">Know More</button>
               
        </div>
	
         <div class="job"> 
             <img src="nlr.png" alt="NLR India Foundation">
                <h2>NLR India Foundation<br>(Content Writing)</h2><br><br>
                <ul>
                    <li>Start Date: 20 October 2021</li>
                    <li>Stipend: 1000/-</li>
                    <li>Duration: 2 month</li>
                    <li>Location: Work from Home</li>
                </ul>
                <button>Know More</button>
        </div>
	
             <div class="job"> 
                 <img src="auum.png" alt="AUUM Platforms">
                <h2>AUUM Platforms<br>(Operations)</h2><br><br>
                <ul>
                    <li>Start Date: 2 November 2021</li>
                    <li>Stipend: 5000/-</li>
                    <li>Duration: 2 months</li>
                    <li>Location: Work from Home</li>
                </ul>
                <button>Know More</button>
        </div>
	
         <div class="job"> 
             <img src="cake.png" alt="Cake Mail">
                <h2>Cake Mail<br>(Human Resources)</h2><br><br>
                <ul>
                    <li>Start Date: Start Immediately</li>
                    <li>Stipend: 5000/-</li>
                    <li>Duration: 6 months</li>
                    <li>Location: Work from Home</li>
                </ul>
                <button>Know More</button>
        </div>
        
         <div class="job"> 
             <img src="Minibox.png" alt="Miniboxoffice">
                <h2>Miniboxoffice<br>(Video Editing)</h2><br><br>
                <ul>
                    <li>Start Date: 2 November 2021</li>
                    <li>Salary: 1000/-</li>
                    <li>Duration: 1 months</li>
                    <li>Location: Work from Home </li>
                </ul>
                <button>Know More</button>
        </div>
	
         <div class="job"> 
             <img src="jec.png" alt="JEC Publication">
                <h2>JEC Publication<br>(Web Development)</h2><br><br>
                <ul>
                    <li>Start Date: 1 November 2021</li>
                    <li>Stipend: 1000/-</li>
                    <li>Duration: 1 months</li>
                    <li>Location: Work from Home</li>
                </ul>
                <button>Know More</button>
        </div>
	
         <div class="job"> 
             <img src="road.png" alt="Roadson Motors Pvt. Ltd.">
                <h2>Roadson Motors Pvt. Ltd.<br>(Graphic Design)</h2><br><br>
                <ul>
                    <li>Start Date: Start Immediately</li>
                    <li>Stipend: 5000/-</li>
                    <li>Duration: 2 months</li>
                    <li>Location: Work from Home</li>
                </ul>
                <button>Know More</button>
        </div>
	
         <div class="job"> 
             <img src="online.png" alt="Online Live Learning">
                <h2>Online Live Learning<br>(Product Management)</h2><br><br>
                <ul>
                    <li>Start Date: Starts Immediately</li>
                    <li>Salary: 15000/-</li>
                    <li>Duration: 6 month</li>
                    <li>Location: Work from Home</li>
                </ul>
                <button>Know More</button>
        </div>
	
         <div class="job"> 
             <img src="botx.png" alt="Botx Automations Pvt. Ltd.">
                <h2>Botx Automations Pvt. Ltd.<br>(UI/UX Design)</h2><br><br>
                <ul>
                    <li>Start Date: 30 November 2021</li>
                    <li>Salary: 1200/-</li>
                    <li>Duration: 6 month</li>
                    <li>Location: Work from Home</li>
                </ul>
                <button>Know More</button>
        </div>
        
         <div class="job"> 
             <img src="digita.png" alt="DigitaArch.com">
                <h2>DigitaArch.com<br>(Business Development - Sales)</h2><br><br>
                <ul>
                    <li>Start Date: Start Immediately</li>
                    <li>Salary: 10000/-</li>
                    <li>Duration: 1 month</li>
                    <li>Location: Work from Home</li>
                </ul>
                <button>Know More</button>
        </div>
	
        <div class="job"> 
            <img src="oddy.png" alt="Oddy Labs">
                <h2>Oddy Labs<br>(Blogging)</h2><br><br>
                <ul>
                    <li>Start Date: 3 November 2022</li>
                    <li>Stipend: 4000/-</li>
                    <li>Duration: 6 months</li>
                    <li>Location: Work from Home</li>
                </ul>
                <button>Know More</button>
        </div>
	



        <a href="#nav" style="margin-left: 40%; font-size: 20px; color: blue;">Click Here To Go At Top</a>
        
        <footer>
            <div class="left">
                <h2>Office Address:</h2>
                <p>B-161<br>Ashok Vihar<br>Delhi-110052<p>
            </div>
            <div class="main" style=" width: 30%; float: left">
                <a href="ourteam.php"">Our Team</a><br>
                <a href="aboutus.php">About Us</a><br>
                <a href="privacypolicy.php">Privacy Policy</a><br>
                <a href="termsnconditions.php">Terms and Conditions</a>
            </div>
            <div class="right">
                <h2>Contact Us:</h2>
                <p>+91 8826033672<br>+91 7718025123<br>+91 9869799006</p>
            </div>
        </footer>

    </body>
</html>
